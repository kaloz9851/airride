import SwiftUI

enum AppRoute {
    case main
    case menu(MenuSection)
}

@main
struct TothWorksAirRideApp: App {
    @StateObject private var viewModel = MainViewModel()
    @State private var route: AppRoute = .main

    var body: some Scene {
        WindowGroup {
            Group {
                switch route {
                case .main:
                    MainScreen(
                        viewModel: viewModel,
                        onNavigateToMenu: { route = .menu(.devices) },
                        onNavigateToAuto: { route = .menu(.autoHold) }
                    )
                case .menu(let initialSection):
                    DeviceMenuScreen(
                        viewModel: viewModel,
                        onNavigateBack: { route = .main },
                        currentSection: initialSection
                    )
                }
            }
            .preferredColorScheme(.dark)
        }
    }
}
