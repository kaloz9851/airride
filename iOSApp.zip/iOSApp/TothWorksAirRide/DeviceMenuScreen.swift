import SwiftUI
import PhotosUI

enum MenuSection: String, CaseIterable, Identifiable {
    case devices    = "MENTETT ESZKÖZÖK"
    case scan       = "ÚJ ESZKÖZ KERESÉSE"
    case appearance = "MEGJELENÉS"
    case extras     = "EXTRÁK"
    case info       = "INFO"

    var id: String { rawValue }
}

struct DeviceMenuScreen: View {
    @ObservedObject var viewModel: MainViewModel
    let onNavigateBack: () -> Void
    @State var currentSection: MenuSection

    @State private var deviceToDelete: SavedDevice? = nil
    @State private var deviceForPinChange: SavedDevice? = nil
    @State private var scannedToConnect: ScannedDevice? = nil
    @State private var connectPinInput = ""
    @State private var connectSavePin = true

    var body: some View {
        ZStack {
            AppTheme.deepBlack.ignoresSafeArea()

            VStack(spacing: 0) {
                // ── Fejléc (TopAppBar) ──
                HStack(spacing: 12) {
                    Button(action: onNavigateBack) {
                        Image(systemName: "arrow.left")
                            .font(.system(size: 18, weight: .bold))
                            .foregroundColor(AppTheme.textPrimary)
                            .frame(width: 36, height: 36)
                    }

                    Text("ESZKÖZKEZELŐ")
                        .font(.system(size: 16, weight: .black))
                        .tracking(3)
                        .foregroundColor(AppTheme.neonBlue)

                    Spacer()

                    Button(action: {
                        viewModel.startScan()
                        currentSection = .scan
                    }) {
                        Image(systemName: "magnifyingglass")
                            .font(.system(size: 18, weight: .bold))
                            .foregroundColor(AppTheme.neonBlue)
                            .frame(width: 36, height: 36)
                    }
                }
                .padding(.horizontal, 12)
                .padding(.vertical, 10)
                .background(AppTheme.darkSurface)

                // ── Görgethető Tab Sáv ──
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 8) {
                        ForEach(MenuSection.allCases) { section in
                            let selected = (section == currentSection)
                            Button(action: {
                                withAnimation(.easeInOut(duration: 0.2)) {
                                    currentSection = section
                                }
                            }) {
                                VStack(spacing: 8) {
                                    Text(section.rawValue)
                                        .font(.system(size: 11, weight: selected ? .bold : .regular))
                                        .tracking(0.6)
                                        .foregroundColor(selected ? AppTheme.neonBlue : AppTheme.textSecondary)
                                        .fixedSize(horizontal: true, vertical: false)
                                        .padding(.horizontal, 10)
                                        .padding(.top, 12)

                                    Rectangle()
                                        .fill(selected ? AppTheme.neonBlue : Color.clear)
                                        .frame(height: 2.5)
                                }
                            }
                        }
                    }
                    .padding(.horizontal, 8)
                }
                .background(AppTheme.darkSurface)

                Divider().background(AppTheme.cardBorder)

                // ── Tartalom ──
                Group {
                    switch currentSection {
                    case .devices:
                        SavedDevicesSectionView(
                            viewModel: viewModel,
                            onDelete: { deviceToDelete = $0 },
                            onChangePin: { deviceForPinChange = $0 }
                        )
                    case .scan:
                        ScanSectionView(
                            viewModel: viewModel,
                            onSelectScanned: { scanned in
                                connectPinInput = ""
                                connectSavePin = true
                                scannedToConnect = scanned
                            }
                        )
                    case .appearance:
                        AppearanceSectionView(viewModel: viewModel)
                    case .extras:
                        ExtrasSectionView(viewModel: viewModel)
                    case .info:
                        InfoSectionView()
                    }
                }
                .frame(maxWidth: 620)
            }
        }
        .alert(item: $deviceToDelete) { dev in
            Alert(
                title: Text("Eszköz törlése"),
                message: Text("Biztosan törlöd a(z) \"\(dev.name)\" eszközt?"),
                primaryButton: .destructive(Text("TÖRLÉS")) {
                    viewModel.deleteDevice(dev)
                },
                secondaryButton: .cancel(Text("MÉGSE"))
            )
        }
        .sheet(item: $deviceForPinChange) { dev in
            DeviceChangePinSheet(device: dev, viewModel: viewModel) {
                deviceForPinChange = nil
            }
        }
        .sheet(item: $scannedToConnect) { scanned in
            ConnectScannedPinSheet(
                scanned: scanned,
                pinInput: $connectPinInput,
                savePin: $connectSavePin,
                onConnect: {
                    viewModel.connectToScanned(scanned, pin: connectPinInput, savePin: connectSavePin)
                    scannedToConnect = nil
                },
                onCancel: {
                    scannedToConnect = nil
                }
            )
        }
    }
}

// MARK: - 1. MENTETT ESZKÖZÖK

struct SavedDevicesSectionView: View {
    @ObservedObject var viewModel: MainViewModel
    let onDelete: (SavedDevice) -> Void
    let onChangePin: (SavedDevice) -> Void

    var body: some View {
        ScrollView {
            VStack(spacing: 12) {
                if viewModel.savedDevices.isEmpty {
                    VStack(spacing: 10) {
                        Image(systemName: "antenna.radiowaves.left.and.right.slash")
                            .font(.system(size: 40))
                            .foregroundColor(AppTheme.textDisabled)
                        Text("Nincs mentett eszköz")
                            .font(.system(size: 15, weight: .bold))
                            .foregroundColor(AppTheme.textSecondary)
                        Text("Használd a keresést új eszköz hozzáadásához")
                            .font(.system(size: 12))
                            .foregroundColor(AppTheme.textDisabled)
                            .multilineTextAlignment(.center)
                    }
                    .padding(.top, 60)
                } else {
                    ForEach(viewModel.savedDevices) { dev in
                        let isActive = (viewModel.activeDevice?.id == dev.id)
                        let isConnected = isActive && (viewModel.connectionState == .authenticated || viewModel.connectionState == .connected)

                        VStack(alignment: .leading, spacing: 10) {
                            HStack {
                                VStack(alignment: .leading, spacing: 3) {
                                    Text(dev.name)
                                        .font(.system(size: 15, weight: .bold))
                                        .foregroundColor(AppTheme.textPrimary)
                                    Text("🚗  \(dev.carName)")
                                        .font(.system(size: 12))
                                        .foregroundColor(AppTheme.neonCyan)
                                }
                                Spacer()
                                if dev.savedPin != nil {
                                    Image(systemName: "lock.fill")
                                        .font(.system(size: 13))
                                        .foregroundColor(AppTheme.neonGreen.opacity(0.75))
                                }
                                if isConnected {
                                    Text("AKTÍV")
                                        .font(.system(size: 10, weight: .black))
                                        .foregroundColor(AppTheme.neonGreen)
                                        .padding(.horizontal, 8)
                                        .padding(.vertical, 4)
                                        .background(AppTheme.neonGreen.opacity(0.18))
                                        .cornerRadius(6)
                                }
                            }

                            HStack(spacing: 8) {
                                Button(action: {
                                    if isConnected {
                                        viewModel.disconnect()
                                    } else {
                                        viewModel.connectToDevice(dev)
                                    }
                                }) {
                                    Text(isConnected ? "LECSATLAKOZÁS" : "CSATLAKOZÁS")
                                        .font(.system(size: 11, weight: .bold))
                                        .foregroundColor(isConnected ? AppTheme.authOrange : AppTheme.neonBlue)
                                        .frame(maxWidth: .infinity)
                                        .padding(.vertical, 10)
                                        .background((isConnected ? AppTheme.authOrange : AppTheme.neonBlue).opacity(0.15))
                                        .overlay(
                                            RoundedRectangle(cornerRadius: 8)
                                                .stroke((isConnected ? AppTheme.authOrange : AppTheme.neonBlue).opacity(0.6), lineWidth: 1)
                                        )
                                        .cornerRadius(8)
                                }

                                Button(action: { onChangePin(dev) }) {
                                    HStack(spacing: 4) {
                                        Image(systemName: "key.fill")
                                        Text("PIN MÓD.")
                                            .font(.system(size: 10, weight: .bold))
                                    }
                                    .foregroundColor(AppTheme.authOrange)
                                    .padding(.horizontal, 12)
                                    .padding(.vertical, 10)
                                    .background(AppTheme.darkSurface)
                                    .cornerRadius(8)
                                    .overlay(RoundedRectangle(cornerRadius: 8).stroke(AppTheme.authOrange.opacity(0.6), lineWidth: 1))
                                }

                                Button(action: { onDelete(dev) }) {
                                    Image(systemName: "trash.fill")
                                        .font(.system(size: 14))
                                        .foregroundColor(AppTheme.neonRed)
                                        .padding(10)
                                        .background(AppTheme.darkSurface)
                                        .cornerRadius(8)
                                        .overlay(RoundedRectangle(cornerRadius: 8).stroke(AppTheme.cardBorder, lineWidth: 1))
                                }
                            }
                        }
                        .padding(14)
                        .background(AppTheme.cardBackground)
                        .overlay(
                            RoundedRectangle(cornerRadius: 12)
                                .stroke(isConnected ? AppTheme.neonGreen.opacity(0.6) : AppTheme.cardBorder, lineWidth: 1)
                        )
                        .cornerRadius(12)
                    }
                }
            }
            .padding(16)
        }
    }
}

// MARK: - 2. ÚJ ESZKÖZ KERESÉSE

struct ScanSectionView: View {
    @ObservedObject var viewModel: MainViewModel
    let onSelectScanned: (ScannedDevice) -> Void

    var body: some View {
        let isScanning = (viewModel.connectionState == .scanning)
        ScrollView {
            VStack(spacing: 14) {
                Button(action: { viewModel.startScan() }) {
                    HStack(spacing: 10) {
                        if isScanning {
                            ProgressView()
                                .tint(AppTheme.neonBlue)
                        } else {
                            Image(systemName: "dot.radiowaves.left.and.right")
                        }
                        Text(isScanning ? "KERESÉS FOLYAMATBAN..." : "KERESÉS INDÍTÁSA")
                            .font(.system(size: 12, weight: .bold))
                            .tracking(1)
                    }
                    .foregroundColor(AppTheme.neonBlue)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 14)
                    .background(AppTheme.neonBlue.opacity(0.15))
                    .overlay(RoundedRectangle(cornerRadius: 10).stroke(AppTheme.neonBlue.opacity(0.65), lineWidth: 1))
                    .cornerRadius(10)
                }

                if viewModel.scannedDevices.isEmpty {
                    Text(isScanning ? "Keresés a közelben lévő TothWorks Air Ride eszközökre..." : "Nyomd meg a KERESÉS gombot az Air Ride eszközök megtalálásához.")
                        .font(.system(size: 12))
                        .foregroundColor(AppTheme.textSecondary)
                        .multilineTextAlignment(.center)
                        .padding(.top, 30)
                } else {
                    ForEach(viewModel.scannedDevices) { item in
                        HStack {
                            VStack(alignment: .leading, spacing: 4) {
                                Text(item.name)
                                    .font(.system(size: 15, weight: .bold))
                                    .foregroundColor(AppTheme.textPrimary)
                                Text("Jelerősség: \(item.rssi) dBm")
                                    .font(.system(size: 11))
                                    .foregroundColor(AppTheme.textSecondary)
                            }
                            Spacer()
                            Button(action: { onSelectScanned(item) }) {
                                Text("CSATLAKOZÁS")
                                    .font(.system(size: 11, weight: .bold))
                                    .foregroundColor(AppTheme.neonGreen)
                                    .padding(.horizontal, 12)
                                    .padding(.vertical, 8)
                                    .background(AppTheme.neonGreen.opacity(0.15))
                                    .overlay(RoundedRectangle(cornerRadius: 8).stroke(AppTheme.neonGreen.opacity(0.6), lineWidth: 1))
                                    .cornerRadius(8)
                            }
                        }
                        .padding(14)
                        .background(AppTheme.cardBackground)
                        .overlay(RoundedRectangle(cornerRadius: 12).stroke(AppTheme.cardBorder, lineWidth: 1))
                        .cornerRadius(12)
                    }
                }
            }
            .padding(16)
        }
    }
}

// MARK: - 3. MEGJELENÉS (Háttérkép választás)

struct AppearanceSectionView: View {
    @ObservedObject var viewModel: MainViewModel
    @State private var selectedItem: PhotosPickerItem? = nil

    var body: some View {
        let hasBg = (viewModel.activeDevice?.backgroundFilename != nil)
        ScrollView {
            VStack(alignment: .leading, spacing: 14) {
                Text("HÁTTÉRKÉP")
                    .font(.system(size: 13, weight: .black))
                    .tracking(2)
                    .foregroundColor(AppTheme.neonBlue)

                Text("Az autó vezérlő képernyőjén megjelenő háttérkép beállítása.")
                    .font(.system(size: 12))
                    .foregroundColor(AppTheme.textSecondary)

                PhotosPicker(selection: $selectedItem, matching: .images) {
                    HStack {
                        Image(systemName: "photo.on.rectangle.angled")
                        Text(hasBg ? "HÁTTÉRKÉP CSERÉJE" : "HÁTTÉRKÉP KIVÁLASZTÁSA")
                            .font(.system(size: 12, weight: .bold))
                            .tracking(1)
                    }
                    .foregroundColor(AppTheme.neonBlue)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 14)
                    .background(AppTheme.neonBlue.opacity(0.15))
                    .overlay(RoundedRectangle(cornerRadius: 10).stroke(AppTheme.neonBlue.opacity(0.65), lineWidth: 1))
                    .cornerRadius(10)
                }
                .onChange(of: selectedItem) { newItem in
                    guard let newItem = newItem else { return }
                    Task {
                        if let data = try? await newItem.loadTransferable(type: Data.self),
                           let uiImage = UIImage(data: data) {
                            await MainActor.run {
                                viewModel.setCustomBackgroundImage(uiImage)
                            }
                        }
                    }
                }

                if hasBg {
                    Button(action: { viewModel.removeCustomBackgroundImage() }) {
                        HStack {
                            Image(systemName: "trash")
                            Text("HÁTTÉRKÉP ELTÁVOLÍTÁSA")
                                .font(.system(size: 11, weight: .bold))
                        }
                        .foregroundColor(AppTheme.neonRed)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 12)
                        .background(AppTheme.neonRed.opacity(0.12))
                        .overlay(RoundedRectangle(cornerRadius: 10).stroke(AppTheme.neonRed.opacity(0.5), lineWidth: 1))
                        .cornerRadius(10)
                    }
                }
            }
            .padding(16)
        }
    }
}

// MARK: - 4. EXTRÁK (R5 és R6 kapcsolók átnevezhető kártyákkal)

struct ExtrasSectionView: View {
    @ObservedObject var viewModel: MainViewModel

    @State private var name1: String = "Extra 1"
    @State private var name2: String = "Extra 2"
    @State private var editing1: Bool = false
    @State private var editing2: Bool = false

    private var isAuth: Bool {
        viewModel.connectionState == .authenticated
    }

    private var canControl: Bool {
        isAuth && viewModel.activeDevice != nil
    }

    var body: some View {
        let r5On = viewModel.relayStates[safe: 4] ?? false
        let r6On = viewModel.relayStates[safe: 5] ?? false

        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                VStack(alignment: .leading, spacing: 4) {
                    Text("EXTRA KAPCSOLÓK")
                        .font(.system(size: 13, weight: .black))
                        .tracking(2)
                        .foregroundColor(AppTheme.neonBlue)

                    Text("R5 és R6 kapcsolók – érintésre be/ki kapcsolnak.")
                        .font(.system(size: 12))
                        .foregroundColor(AppTheme.textSecondary)
                }

                // R5 – Extra 1 kapcsoló
                ExtraToggleCardView(
                    relayLabel: "R5",
                    switchName: $name1,
                    isOn: r5On,
                    isEnabled: canControl,
                    isEditing: $editing1,
                    onToggle: { viewModel.toggleExtra(4) },
                    onSaveName: {
                        editing1 = false
                        if let dev = viewModel.activeDevice {
                            viewModel.updateExtraNames(deviceId: dev.id, name1: name1, name2: name2)
                        }
                    }
                )

                // R6 – Extra 2 kapcsoló
                ExtraToggleCardView(
                    relayLabel: "R6",
                    switchName: $name2,
                    isOn: r6On,
                    isEnabled: canControl,
                    isEditing: $editing2,
                    onToggle: { viewModel.toggleExtra(5) },
                    onSaveName: {
                        editing2 = false
                        if let dev = viewModel.activeDevice {
                            viewModel.updateExtraNames(deviceId: dev.id, name1: name1, name2: name2)
                        }
                    }
                )

                if !isAuth {
                    HStack(spacing: 8) {
                        Image(systemName: "exclamationmark.triangle.fill")
                            .foregroundColor(AppTheme.authOrange)
                        Text("A kapcsolók vezérléséhez csatlakozz az eszközhöz.")
                            .font(.system(size: 12))
                            .foregroundColor(AppTheme.authOrange)
                        Spacer()
                    }
                    .padding(12)
                    .background(AppTheme.cardBackground)
                    .overlay(RoundedRectangle(cornerRadius: 10).stroke(AppTheme.authOrange.opacity(0.45), lineWidth: 1))
                    .cornerRadius(10)
                }
            }
            .padding(16)
        }
        .onAppear {
            name1 = viewModel.activeDevice?.extra1Name ?? "Extra 1"
            name2 = viewModel.activeDevice?.extra2Name ?? "Extra 2"
        }
        .onChange(of: viewModel.activeDevice) { dev in
            name1 = dev?.extra1Name ?? "Extra 1"
            name2 = dev?.extra2Name ?? "Extra 2"
        }
    }
}

struct ExtraToggleCardView: View {
    let relayLabel: String
    @Binding var switchName: String
    let isOn: Bool
    let isEnabled: Bool
    @Binding var isEditing: Bool
    let onToggle: () -> Void
    let onSaveName: () -> Void

    var body: some View {
        let stateColor = isOn ? AppTheme.neonGreen : AppTheme.textSecondary
        let stateLabel = isOn ? "BE" : "KI"

        VStack(alignment: .leading, spacing: 14) {
            HStack(spacing: 10) {
                Text(relayLabel)
                    .font(.system(size: 11, weight: .bold))
                    .foregroundColor(AppTheme.neonBlue)
                    .padding(.horizontal, 8)
                    .padding(.vertical, 4)
                    .background(AppTheme.darkSurface)
                    .cornerRadius(6)

                if isEditing {
                    TextField("Kapcsoló neve", text: $switchName)
                        .font(.system(size: 14, weight: .bold))
                        .foregroundColor(AppTheme.textPrimary)
                        .padding(8)
                        .background(AppTheme.darkSurface)
                        .cornerRadius(6)
                        .overlay(RoundedRectangle(cornerRadius: 6).stroke(AppTheme.neonBlue, lineWidth: 1))

                    Button(action: onSaveName) {
                        Image(systemName: "checkmark.circle.fill")
                            .font(.system(size: 20))
                            .foregroundColor(AppTheme.neonGreen)
                    }
                } else {
                    Text(switchName)
                        .font(.system(size: 16, weight: .bold))
                        .foregroundColor(AppTheme.textPrimary)

                    Spacer()

                    Button(action: { isEditing = true }) {
                        Image(systemName: "pencil")
                            .font(.system(size: 14))
                            .foregroundColor(AppTheme.textSecondary)
                    }
                }

                Text(stateLabel)
                    .font(.system(size: 12, weight: .black))
                    .foregroundColor(stateColor)
                    .padding(.horizontal, 10)
                    .padding(.vertical, 4)
                    .background(stateColor.opacity(0.15))
                    .cornerRadius(6)
            }

            Button(action: onToggle) {
                HStack(spacing: 8) {
                    Image(systemName: isOn ? "power.circle.fill" : "power.circle")
                        .font(.system(size: 20))
                    Text(isOn
                         ? "BEKAPCSOLT – érintsd meg a kikapcsoláshoz"
                         : "KIKAPCSOLT – érintsd meg a bekapcsoláshoz")
                        .font(.system(size: 13, weight: .semibold))
                }
                .foregroundColor(isEnabled ? (isOn ? AppTheme.neonGreen : AppTheme.textPrimary) : AppTheme.textDisabled)
                .frame(maxWidth: .infinity)
                .frame(height: 52)
                .background(isOn ? AppTheme.neonGreen.opacity(0.18) : AppTheme.darkSurface)
                .overlay(
                    RoundedRectangle(cornerRadius: 10)
                        .stroke(isOn ? AppTheme.neonGreen.opacity(0.6) : AppTheme.cardBorder, lineWidth: 1.5)
                )
                .cornerRadius(10)
            }
            .disabled(!isEnabled)
        }
        .padding(16)
        .background(isOn ? AppTheme.neonGreen.opacity(0.06) : AppTheme.cardBackground)
        .overlay(
            RoundedRectangle(cornerRadius: 12)
                .stroke(isOn ? AppTheme.neonGreen.opacity(0.5) : AppTheme.cardBorder, lineWidth: 1)
        )
        .cornerRadius(12)
    }
}

// MARK: - 5. INFO SZEKCIÓ

struct InfoSectionView: View {
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 14) {
                VStack(alignment: .leading, spacing: 12) {
                    if UIImage(named: "tothworks_logo") != nil {
                        HStack {
                            Spacer()
                            Image("tothworks_logo")
                                .resizable()
                                .scaledToFit()
                                .frame(height: 52)
                            Spacer()
                        }
                    }

                    Text("Toth Works air ride remote system")
                        .font(.system(size: 16, weight: .black))
                        .foregroundColor(AppTheme.neonBlue)
                        .frame(maxWidth: .infinity, alignment: .center)

                    Divider().background(AppTheme.cardBorder)

                    HStack {
                        VStack(alignment: .leading) {
                            Text("Készítette:")
                                .font(.system(size: 11))
                                .foregroundColor(AppTheme.textSecondary)
                            Text("Lizi Design - Barni")
                                .font(.system(size: 13, weight: .bold))
                                .foregroundColor(AppTheme.textPrimary)
                        }
                        Spacer()
                        VStack(alignment: .trailing) {
                            Text("Forgalmazó:")
                                .font(.system(size: 11))
                                .foregroundColor(AppTheme.textSecondary)
                            Text("TOTH WORKS")
                                .font(.system(size: 13, weight: .black))
                                .foregroundColor(AppTheme.neonCyan)
                        }
                    }

                    Divider().background(AppTheme.cardBorder)

                    Text("ÁSZF ÉS FELHASZNÁLÁSI TUDNIVALÓK")
                        .font(.system(size: 12, weight: .black))
                        .foregroundColor(AppTheme.neonCyan)

                    Text("""
ASZF: A készüléket verseny célra és egyéni magánszemélyek szenvédélyből történő tuning építések kiegészítésére ajánljuk. A készülék és az applikáció semilyen személyes adatot nem tárol, vagy használ fel! A készülék és az applikáció is aktív tesztelésen esett át (stressz teszt) így kereskedelmi forgalomba hozható struktúrális egységet képez. Minden felhasznált anyag és alkatrész MAGYAR beszállítóktól származik. A jelszó módosításához pontos leírást biztonsági okokból a termékhez kapott adatlapon találhatsz.

A termék bekötése egyszerű, lentebb található rajz alapján bárki bekötheti a meglévő rendszere, világításai kapcsolójával párhuzamosan, vagy azok helyett.

A termék bekötéséből és használatából adódó eszközök károsodásáért a fejlesztőt és az eszköz beszerelését végző személy nem vonható felelősségre. A termék kizárólag 1-12v max 10A kapcsolását teszi lehetővé. Belső feszültségét galvanikus leválasztás miatt a kapcsolók irányába kivezetni nem lehet. A készülék helytelen bekötésére garanciális javítás nem alkalmazható! Az alaplapján külön részegység felel a fordított polaritás miatti meghibásodás jelzésére.

Garanciális javítás a fejlesztőnél lehetséges: 7400, Kaposvár Vak Bottyán utca 64. info@4k2k.hu.

Sok örömteli kilómétert és rengeteg csodálkozó arcot kíván a TOTH WORKS és a Lizi Design csapata.
""")
                        .font(.system(size: 12))
                        .foregroundColor(AppTheme.textPrimary)
                        .lineSpacing(4)
                }
                .padding(16)
                .background(AppTheme.cardBackground)
                .overlay(RoundedRectangle(cornerRadius: 12).stroke(AppTheme.cardBorder, lineWidth: 1))
                .cornerRadius(12)

                // Bekötési rajz kártya (R1..R6 csatornák + conn_logo.png)
                VStack(alignment: .leading, spacing: 10) {
                    Text("BEKÖTÉSI RAJZ & KAPCSOLÁSI SÉMA")
                        .font(.system(size: 12, weight: .black))
                        .foregroundColor(AppTheme.neonCyan)

                    if UIImage(named: "conn_logo") != nil {
                        Image("conn_logo")
                            .resizable()
                            .scaledToFit()
                            .cornerRadius(8)
                    }

                    Text("R1: Első tengely FEL (levegő be szelep)\nR2: Első tengely LE (levegő ki szelep)\nR3: Hátsó tengely FEL (levegő be szelep)\nR4: Hátsó tengely LE (levegő ki szelep)\nR5: Extra 1 kapcsoló (világítás, stb.)\nR6: Extra 2 kapcsoló (kompresszor, stb.)")
                        .font(.system(size: 11, weight: .medium))
                        .foregroundColor(AppTheme.textSecondary)
                        .lineSpacing(3)
                }
                .padding(16)
                .background(AppTheme.cardBackground)
                .overlay(RoundedRectangle(cornerRadius: 12).stroke(AppTheme.cardBorder, lineWidth: 1))
                .cornerRadius(12)

                // Tanúsítványok
                VStack(spacing: 8) {
                    Text("ROHS - CE - BLUETOOTH - WIFI - ESP- \"2025\"")
                        .font(.system(size: 12, weight: .black))
                        .tracking(1)
                        .foregroundColor(AppTheme.neonBlue)
                }
                .frame(maxWidth: .infinity)
                .padding(14)
                .background(AppTheme.cardBackground)
                .overlay(RoundedRectangle(cornerRadius: 12).stroke(AppTheme.cardBorder, lineWidth: 1))
                .cornerRadius(12)
            }
            .padding(16)
        }
    }
}

// MARK: - Segéd Sheet-ek (PIN csere & Új eszköz csatlakozás)

struct DeviceChangePinSheet: View {
    let device: SavedDevice
    @ObservedObject var viewModel: MainViewModel
    let onDismiss: () -> Void

    @State private var newPin = ""
    @State private var useMaster = false
    @State private var masterPw = ""

    var body: some View {
        ZStack {
            AppTheme.deepBlack.ignoresSafeArea()
            VStack(spacing: 14) {
                Text("PIN MÓDOSÍTÁS – \(device.name)")
                    .font(.system(size: 15, weight: .black))
                    .foregroundColor(AppTheme.neonBlue)

                SecureField("Új 4 jegyű PIN", text: $newPin)
                    .keyboardType(.numberPad)
                    .padding(12)
                    .background(AppTheme.cardBackground)
                    .foregroundColor(AppTheme.textPrimary)
                    .cornerRadius(8)
                    .onChange(of: newPin) { val in
                        newPin = String(val.filter { $0.isNumber }.prefix(4))
                    }

                Toggle("Mesterjelszó használata", isOn: $useMaster)
                    .font(.system(size: 12))
                    .foregroundColor(AppTheme.textSecondary)
                    .tint(AppTheme.authOrange)

                if useMaster {
                    SecureField("Mesterjelszó", text: $masterPw)
                        .padding(12)
                        .background(AppTheme.cardBackground)
                        .foregroundColor(AppTheme.textPrimary)
                        .cornerRadius(8)
                }

                HStack(spacing: 12) {
                    Button("MÉGSE", action: onDismiss)
                        .font(.system(size: 13, weight: .bold))
                        .foregroundColor(AppTheme.textSecondary)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 12)
                        .background(AppTheme.cardBackground)
                        .cornerRadius(8)

                    Button("MENTÉS") {
                        if newPin.count == 4 {
                            if useMaster {
                                viewModel.authenticateMaster(masterPw)
                            }
                            viewModel.changePin(newPin)
                            onDismiss()
                        }
                    }
                    .font(.system(size: 13, weight: .bold))
                    .foregroundColor(AppTheme.deepBlack)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 12)
                    .background(newPin.count == 4 ? AppTheme.neonBlue : AppTheme.textDisabled)
                    .cornerRadius(8)
                }
            }
            .padding(24)
        }
        .presentationDetents([.height(310)])
    }
}

struct ConnectScannedPinSheet: View {
    let scanned: ScannedDevice
    @Binding var pinInput: String
    @Binding var savePin: Bool
    let onConnect: () -> Void
    let onCancel: () -> Void

    var body: some View {
        ZStack {
            AppTheme.deepBlack.ignoresSafeArea()
            VStack(spacing: 16) {
                Text(scanned.name)
                    .font(.system(size: 16, weight: .black))
                    .foregroundColor(AppTheme.neonBlue)

                SecureField("4 jegyű PIN (alapértelmezett: 1234)", text: $pinInput)
                    .keyboardType(.numberPad)
                    .padding(12)
                    .background(AppTheme.cardBackground)
                    .foregroundColor(AppTheme.textPrimary)
                    .cornerRadius(8)
                    .overlay(RoundedRectangle(cornerRadius: 8).stroke(AppTheme.neonBlue, lineWidth: 1))
                    .onChange(of: pinInput) { val in
                        pinInput = String(val.filter { $0.isNumber }.prefix(4))
                    }

                Toggle("PIN mentése auto-csatlakozáshoz", isOn: $savePin)
                    .font(.system(size: 12))
                    .foregroundColor(AppTheme.textSecondary)
                    .tint(AppTheme.neonBlue)

                HStack(spacing: 12) {
                    Button("MÉGSE", action: onCancel)
                        .font(.system(size: 13, weight: .bold))
                        .foregroundColor(AppTheme.textSecondary)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 12)
                        .background(AppTheme.cardBackground)
                        .cornerRadius(8)

                    Button("CSATLAKOZÁS") {
                        if pinInput.count == 4 {
                            onConnect()
                        }
                    }
                    .font(.system(size: 13, weight: .bold))
                    .foregroundColor(AppTheme.deepBlack)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 12)
                    .background(pinInput.count == 4 ? AppTheme.neonGreen : AppTheme.textDisabled)
                    .cornerRadius(8)
                }
            }
            .padding(24)
        }
        .presentationDetents([.height(280)])
    }
}
