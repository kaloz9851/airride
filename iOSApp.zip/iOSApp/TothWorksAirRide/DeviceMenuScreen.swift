import SwiftUI
import PhotosUI

enum MenuSection: String, CaseIterable, Identifiable {
    case devices    = "MENTETT ESZKÖZÖK"
    case scan       = "ÚJ ESZKÖZ KERESÉSE"
    case appearance = "MEGJELENÉS"
    case pressure   = "NYOMÁSMÉRŐ"
    case autoHold   = "AUTO NYOMÁSTARTÁS"
    case info       = "INFO"

    var id: String { rawValue }
}

struct DeviceMenuScreen: View {
    @ObservedObject var viewModel: MainViewModel
    let onNavigateBack: () -> Void
    @State var currentSection: MenuSection

    @State private var deviceToDelete: SavedDevice? = nil
    @State private var deviceForPinChange: SavedDevice? = nil
    @State private var scannedToConnect: ScannedDevice? = nil
    @State private var connectPinInput = ""
    @State private var connectSavePin = true

    var body: some View {
        ZStack {
            AppTheme.deepBlack.ignoresSafeArea()

            VStack(spacing: 0) {
                // ── Fejléc (TopAppBar) ──
                HStack(spacing: 12) {
                    Button(action: onNavigateBack) {
                        Image(systemName: "arrow.left")
                            .font(.system(size: 18, weight: .bold))
                            .foregroundColor(AppTheme.textPrimary)
                            .frame(width: 36, height: 36)
                    }

                    Text("ESZKÖZKEZELŐ")
                        .font(.system(size: 16, weight: .black))
                        .tracking(3)
                        .foregroundColor(AppTheme.neonBlue)

                    Spacer()

                    Button(action: {
                        viewModel.startScan()
                        currentSection = .scan
                    }) {
                        Image(systemName: "magnifyingglass")
                            .font(.system(size: 18, weight: .bold))
                            .foregroundColor(AppTheme.neonBlue)
                            .frame(width: 36, height: 36)
                    }
                }
                .padding(.horizontal, 12)
                .padding(.vertical, 10)
                .background(AppTheme.darkSurface)

                // ── Görgethető Tab Sáv (nem csúsznak össze a feliratok) ──
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 8) {
                        ForEach(MenuSection.allCases) { section in
                            let selected = (section == currentSection)
                            Button(action: {
                                withAnimation(.easeInOut(duration: 0.2)) {
                                    currentSection = section
                                }
                            }) {
                                VStack(spacing: 8) {
                                    Text(section.rawValue)
                                        .font(.system(size: 11, weight: selected ? .bold : .regular))
                                        .tracking(0.6)
                                        .foregroundColor(selected ? AppTheme.neonBlue : AppTheme.textSecondary)
                                        .fixedSize(horizontal: true, vertical: false)
                                        .padding(.horizontal, 10)
                                        .padding(.top, 12)

                                    Rectangle()
                                        .fill(selected ? AppTheme.neonBlue : Color.clear)
                                        .frame(height: 2.5)
                                }
                            }
                        }
                    }
                    .padding(.horizontal, 8)
                }
                .background(AppTheme.darkSurface)

                Divider().background(AppTheme.cardBorder)

                // ── Tartalom ──
                Group {
                    switch currentSection {
                    case .devices:
                        SavedDevicesSectionView(
                            viewModel: viewModel,
                            onDelete: { deviceToDelete = $0 },
                            onChangePin: { deviceForPinChange = $0 }
                        )
                    case .scan:
                        ScanSectionView(
                            viewModel: viewModel,
                            onSelectScanned: { scanned in
                                connectPinInput = ""
                                connectSavePin = true
                                scannedToConnect = scanned
                            }
                        )
                    case .appearance:
                        AppearanceSectionView(viewModel: viewModel)
                    case .pressure:
                        PressureSensorSectionView(viewModel: viewModel)
                    case .autoHold:
                        AutoHoldSectionView(viewModel: viewModel)
                    case .info:
                        InfoSectionView()
                    }
                }
                .frame(maxWidth: 620)
            }
        }
        .alert(item: $deviceToDelete) { dev in
            Alert(
                title: Text("Eszköz törlése"),
                message: Text("Biztosan törlöd a(z) \"\(dev.name)\" eszközt?"),
                primaryButton: .destructive(Text("TÖRLÉS")) {
                    viewModel.deleteDevice(dev)
                },
                secondaryButton: .cancel(Text("MÉGSE"))
            )
        }
        .sheet(item: $deviceForPinChange) { dev in
            DeviceChangePinSheet(device: dev, viewModel: viewModel) {
                deviceForPinChange = nil
            }
        }
        .sheet(item: $scannedToConnect) { scanned in
            ConnectScannedPinSheet(
                scanned: scanned,
                pinInput: $connectPinInput,
                savePin: $connectSavePin,
                onConnect: {
                    viewModel.connectToScanned(scanned, pin: connectPinInput, savePin: connectSavePin)
                    scannedToConnect = nil
                },
                onCancel: {
                    scannedToConnect = nil
                }
            )
        }
    }
}

// MARK: - 1. MENTETT ESZKÖZÖK

struct SavedDevicesSectionView: View {
    @ObservedObject var viewModel: MainViewModel
    let onDelete: (SavedDevice) -> Void
    let onChangePin: (SavedDevice) -> Void

    var body: some View {
        ScrollView {
            VStack(spacing: 12) {
                if viewModel.savedDevices.isEmpty {
                    VStack(spacing: 10) {
                        Image(systemName: "antenna.radiowaves.left.and.right.slash")
                            .font(.system(size: 40))
                            .foregroundColor(AppTheme.textDisabled)
                        Text("Nincs mentett eszköz")
                            .font(.system(size: 15, weight: .bold))
                            .foregroundColor(AppTheme.textSecondary)
                        Text("Koppints a nagyító ikonra vagy az „ÚJ ESZKÖZ KERESÉSE” fülre.")
                            .font(.system(size: 12))
                            .foregroundColor(AppTheme.textDisabled)
                            .multilineTextAlignment(.center)
                    }
                    .padding(.top, 60)
                } else {
                    ForEach(viewModel.savedDevices) { dev in
                        let isActive = (viewModel.activeDevice?.id == dev.id)
                        let isConnected = isActive && (viewModel.connectionState == .authenticated || viewModel.connectionState == .connected)

                        VStack(alignment: .leading, spacing: 10) {
                            HStack {
                                VStack(alignment: .leading, spacing: 3) {
                                    Text(dev.name)
                                        .font(.system(size: 15, weight: .bold))
                                        .foregroundColor(AppTheme.textPrimary)
                                    Text("Autó: \(dev.carName)")
                                        .font(.system(size: 12))
                                        .foregroundColor(AppTheme.neonCyan)
                                }
                                Spacer()
                                if isConnected {
                                    Text("AKTÍV")
                                        .font(.system(size: 10, weight: .black))
                                        .foregroundColor(AppTheme.neonGreen)
                                        .padding(.horizontal, 8)
                                        .padding(.vertical, 4)
                                        .background(AppTheme.neonGreen.opacity(0.18))
                                        .cornerRadius(6)
                                }
                            }

                            HStack(spacing: 8) {
                                Button(action: {
                                    if isConnected {
                                        viewModel.disconnect()
                                    } else {
                                        viewModel.connectToDevice(dev)
                                    }
                                }) {
                                    Text(isConnected ? "LECSATLAKOZÁS" : "CSATLAKOZÁS")
                                        .font(.system(size: 11, weight: .bold))
                                        .foregroundColor(isConnected ? AppTheme.authOrange : AppTheme.neonBlue)
                                        .frame(maxWidth: .infinity)
                                        .padding(.vertical, 10)
                                        .background((isConnected ? AppTheme.authOrange : AppTheme.neonBlue).opacity(0.15))
                                        .overlay(
                                            RoundedRectangle(cornerRadius: 8)
                                                .stroke((isConnected ? AppTheme.authOrange : AppTheme.neonBlue).opacity(0.6), lineWidth: 1)
                                        )
                                        .cornerRadius(8)
                                }

                                Button(action: { onChangePin(dev) }) {
                                    Image(systemName: "key.fill")
                                        .font(.system(size: 14))
                                        .foregroundColor(AppTheme.neonCyan)
                                        .padding(10)
                                        .background(AppTheme.darkSurface)
                                        .cornerRadius(8)
                                        .overlay(RoundedRectangle(cornerRadius: 8).stroke(AppTheme.cardBorder, lineWidth: 1))
                                }

                                Button(action: { onDelete(dev) }) {
                                    Image(systemName: "trash.fill")
                                        .font(.system(size: 14))
                                        .foregroundColor(AppTheme.neonRed)
                                        .padding(10)
                                        .background(AppTheme.darkSurface)
                                        .cornerRadius(8)
                                        .overlay(RoundedRectangle(cornerRadius: 8).stroke(AppTheme.cardBorder, lineWidth: 1))
                                }
                            }
                        }
                        .padding(14)
                        .background(AppTheme.cardBackground)
                        .overlay(
                            RoundedRectangle(cornerRadius: 12)
                                .stroke(isConnected ? AppTheme.neonGreen.opacity(0.6) : AppTheme.cardBorder, lineWidth: 1)
                        )
                        .cornerRadius(12)
                    }
                }
            }
            .padding(16)
        }
    }
}

// MARK: - 2. ÚJ ESZKÖZ KERESÉSE

struct ScanSectionView: View {
    @ObservedObject var viewModel: MainViewModel
    let onSelectScanned: (ScannedDevice) -> Void

    var body: some View {
        let isScanning = (viewModel.connectionState == .scanning)
        ScrollView {
            VStack(spacing: 14) {
                Button(action: { viewModel.startScan() }) {
                    HStack(spacing: 10) {
                        if isScanning {
                            ProgressView()
                                .tint(AppTheme.neonBlue)
                        } else {
                            Image(systemName: "dot.radiowaves.left.and.right")
                        }
                        Text(isScanning ? "KERESÉS FOLYAMATBAN..." : "BLUETOOTH KERESÉS INDÍTÁSA")
                            .font(.system(size: 12, weight: .bold))
                            .tracking(1)
                    }
                    .foregroundColor(AppTheme.neonBlue)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 14)
                    .background(AppTheme.neonBlue.opacity(0.15))
                    .overlay(RoundedRectangle(cornerRadius: 10).stroke(AppTheme.neonBlue.opacity(0.65), lineWidth: 1))
                    .cornerRadius(10)
                }

                if viewModel.scannedDevices.isEmpty {
                    Text(isScanning ? "Keresés a közelben lévő TothWorks Air Ride eszközökre..." : "Nincs találat. Nyomd meg a keresés gombot!")
                        .font(.system(size: 12))
                        .foregroundColor(AppTheme.textSecondary)
                        .multilineTextAlignment(.center)
                        .padding(.top, 30)
                } else {
                    ForEach(viewModel.scannedDevices) { item in
                        HStack {
                            VStack(alignment: .leading, spacing: 4) {
                                Text(item.name)
                                    .font(.system(size: 15, weight: .bold))
                                    .foregroundColor(AppTheme.textPrimary)
                                Text("Jelerősség: \(item.rssi) dBm")
                                    .font(.system(size: 11))
                                    .foregroundColor(AppTheme.textSecondary)
                            }
                            Spacer()
                            Button(action: { onSelectScanned(item) }) {
                                Text("PÁROSÍTÁS")
                                    .font(.system(size: 11, weight: .bold))
                                    .foregroundColor(AppTheme.neonGreen)
                                    .padding(.horizontal, 12)
                                    .padding(.vertical, 8)
                                    .background(AppTheme.neonGreen.opacity(0.15))
                                    .overlay(RoundedRectangle(cornerRadius: 8).stroke(AppTheme.neonGreen.opacity(0.6), lineWidth: 1))
                                    .cornerRadius(8)
                            }
                        }
                        .padding(14)
                        .background(AppTheme.cardBackground)
                        .overlay(RoundedRectangle(cornerRadius: 12).stroke(AppTheme.cardBorder, lineWidth: 1))
                        .cornerRadius(12)
                    }
                }
            }
            .padding(16)
        }
    }
}

// MARK: - 3. MEGJELENÉS (Háttérkép választás)

struct AppearanceSectionView: View {
    @ObservedObject var viewModel: MainViewModel
    @State private var selectedItem: PhotosPickerItem? = nil

    var body: some View {
        let hasBg = (viewModel.activeDevice?.backgroundFilename != nil)
        ScrollView {
            VStack(alignment: .leading, spacing: 14) {
                Text("FŐKÉPERNYŐ HÁTTÉRKÉP")
                    .font(.system(size: 13, weight: .black))
                    .tracking(2)
                    .foregroundColor(AppTheme.neonBlue)

                Text("Válassz saját fotót az autóról a galériából, vagy használd az alapértelmezett Carbon Fiber hátteret.")
                    .font(.system(size: 12))
                    .foregroundColor(AppTheme.textSecondary)

                PhotosPicker(selection: $selectedItem, matching: .images) {
                    HStack {
                        Image(systemName: "photo.on.rectangle.angled")
                        Text("SAJÁT HÁTTÉRKÉP KIVÁLASZTÁSA")
                            .font(.system(size: 12, weight: .bold))
                            .tracking(1)
                    }
                    .foregroundColor(AppTheme.neonBlue)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 14)
                    .background(AppTheme.neonBlue.opacity(0.15))
                    .overlay(RoundedRectangle(cornerRadius: 10).stroke(AppTheme.neonBlue.opacity(0.65), lineWidth: 1))
                    .cornerRadius(10)
                }
                .onChange(of: selectedItem) { newItem in
                    guard let newItem = newItem else { return }
                    Task {
                        if let data = try? await newItem.loadTransferable(type: Data.self),
                           let uiImage = UIImage(data: data) {
                            await MainActor.run {
                                viewModel.setCustomBackgroundImage(uiImage)
                            }
                        }
                    }
                }

                if hasBg {
                    Button(action: { viewModel.removeCustomBackgroundImage() }) {
                        HStack {
                            Image(systemName: "trash")
                            Text("ALAPÉRTELMEZETT CARBON HÁTTÉR VISSZAÁLLÍTÁSA")
                                .font(.system(size: 11, weight: .bold))
                        }
                        .foregroundColor(AppTheme.neonRed)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 12)
                        .background(AppTheme.neonRed.opacity(0.12))
                        .overlay(RoundedRectangle(cornerRadius: 10).stroke(AppTheme.neonRed.opacity(0.5), lineWidth: 1))
                        .cornerRadius(10)
                    }
                }
            }
            .padding(16)
        }
    }
}

// MARK: - 4. NYOMÁSMÉRŐ (Élő értékek és kalibráció)

struct PressureSensorSectionView: View {
    @ObservedObject var viewModel: MainViewModel
    @State private var dirty = false
    @State private var savedMsg = false
    @State private var lastSavedCounter = 0

    private var isAuth: Bool {
        viewModel.connectionState == .authenticated
    }

    private let titles = ["ELSŐ TENGELY (A0)", "KÖZÖS (A1)", "HÁTSÓ TENGELY (A2)"]

    var body: some View {
        let statusColor: Color = {
            if !isAuth { return AppTheme.textSecondary }
            return viewModel.adsOk ? AppTheme.neonGreen : AppTheme.neonRed
        }()

        ScrollView {
            VStack(alignment: .leading, spacing: 14) {
                Text("NYOMÁSMÉRŐK KALIBRÁLÁSA")
                    .font(.system(size: 13, weight: .black))
                    .tracking(2)
                    .foregroundColor(AppTheme.neonBlue)

                Text("Alul az élő nyomásértékek kalibrációja után a kalibrált értékeket a „MENTÉS AZ ESZKÖZBE” gombbal tárolhatod a vezérlő EEPROM-jában (NVS).")
                    .font(.system(size: 12))
                    .foregroundColor(AppTheme.textSecondary)

                // ADS1115 állapot kártya
                HStack(spacing: 10) {
                    Image(systemName: (viewModel.adsOk || !isAuth) ? "checkmark.circle.fill" : "exclamationmark.triangle.fill")
                        .font(.system(size: 20))
                        .foregroundColor(statusColor)

                    VStack(alignment: .leading, spacing: 2) {
                        Text(!isAuth
                             ? "Nyomásmérő modul: csatlakozz az eszközhöz"
                             : (viewModel.adsOk ? "Nyomásmérő modul: OK" : "Nyomásmérő modul: NEM TALÁLHATÓ"))
                            .font(.system(size: 13, weight: .bold))
                            .foregroundColor(statusColor)

                        if isAuth && !viewModel.adsOk {
                            Text("Belső modul meghibásodás történt! Csatlakoztasd le a vezérlőt és ellenőrizd a vezérlő alaplapján az ADS1115 modul forrasztásait.")
                                .font(.system(size: 11))
                                .foregroundColor(AppTheme.textSecondary)
                        }
                    }
                    Spacer()
                }
                .padding(12)
                .background(AppTheme.cardBackground)
                .overlay(RoundedRectangle(cornerRadius: 10).stroke(statusColor.opacity(0.5), lineWidth: 1))
                .cornerRadius(10)

                // 3 db Szenzor kártya
                ForEach(0..<3, id: \.self) { i in
                    SensorCalCardView(
                        title: titles[i],
                        psi: viewModel.pressures[safe: i] ?? 0,
                        voltage: viewModel.voltages[safe: i] ?? 0,
                        cal: viewModel.calibrations[safe: i] ?? SensorCal(),
                        enabled: isAuth && viewModel.adsOk,
                        onZero: {
                            viewModel.calibrateZero(i)
                            dirty = true
                        },
                        onSpan: { ref in
                            viewModel.calibrateSpan(i, referencePsi: ref)
                            dirty = true
                        },
                        onReset: {
                            viewModel.calibrateReset(i)
                            dirty = true
                        }
                    )
                }

                // Mentés az EEPROM-ba
                VStack(alignment: .leading, spacing: 10) {
                    Text(savedMsg
                         ? "✔ Kalibráció elmentve a vezérlő EEPROM-jába"
                         : (dirty ? "Nem mentett kalibrációs változtatások!" : "Minden rendben, a kalibráció megegyezik a vezérlőben tároltal."))
                        .font(.system(size: 12, weight: .semibold))
                        .foregroundColor(savedMsg ? AppTheme.neonGreen : (dirty ? AppTheme.authOrange : AppTheme.textSecondary))

                    Button(action: { viewModel.saveCalibration() }) {
                        HStack(spacing: 8) {
                            Image(systemName: "square.and.arrow.down.fill")
                            Text("MENTÉS AZ ESZKÖZBE (EEPROM)")
                                .font(.system(size: 12, weight: .bold))
                                .tracking(1)
                        }
                        .foregroundColor(isAuth ? AppTheme.neonBlue : AppTheme.textDisabled)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 14)
                        .background(isAuth ? AppTheme.neonBlue.opacity(0.2) : AppTheme.darkSurface)
                        .overlay(RoundedRectangle(cornerRadius: 10).stroke(AppTheme.neonBlue.opacity(0.6), lineWidth: 1))
                        .cornerRadius(10)
                    }
                    .disabled(!isAuth)
                }
                .padding(14)
                .background(AppTheme.cardBackground)
                .overlay(RoundedRectangle(cornerRadius: 12).stroke(dirty ? AppTheme.authOrange.opacity(0.6) : AppTheme.cardBorder, lineWidth: 1))
                .cornerRadius(12)
            }
            .padding(16)
        }
        .onAppear {
            lastSavedCounter = viewModel.calSavedCounter
            if isAuth {
                viewModel.requestCalibration()
            }
        }
        .onChange(of: viewModel.calSavedCounter) { newVal in
            if newVal != lastSavedCounter {
                lastSavedCounter = newVal
                dirty = false
                savedMsg = true
                DispatchQueue.main.asyncAfter(deadline: .now() + 3.0) {
                    savedMsg = false
                }
            }
        }
    }
}

struct SensorCalCardView: View {
    let title: String
    let psi: Float
    let voltage: Float
    let cal: SensorCal
    let enabled: Bool
    let onZero: () -> Void
    let onSpan: (Float) -> Void
    let onReset: () -> Void

    @State private var refText = ""

    private var refValue: Float? {
        Float(refText.trimmingCharacters(in: .whitespaces).replacingOccurrences(of: ",", with: "."))
    }

    private var refValid: Bool {
        guard let v = refValue else { return false }
        return v > 0 && v <= PressurePreset.maxPsi
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Text(title)
                    .font(.system(size: 12, weight: .bold))
                    .tracking(1)
                    .foregroundColor(AppTheme.neonCyan)
                Spacer()
                HStack(alignment: .lastTextBaseline, spacing: 4) {
                    Text(enabled ? String(format: "%.1f", locale: Locale(identifier: "en_US"), max(0, psi)) : "--.-")
                        .font(.system(size: 24, weight: .black))
                        .foregroundColor(enabled ? AppTheme.neonBlue : AppTheme.textDisabled)
                    Text("PSI")
                        .font(.system(size: 10))
                        .foregroundColor(AppTheme.textSecondary)
                }
            }

            Divider().background(AppTheme.cardBorder)

            infoRow("Mért feszültség", enabled ? String(format: "%.3f V", locale: Locale(identifier: "en_US"), voltage) : "-")
            infoRow("Nullpont (0 psi)", String(format: "%.3f V", locale: Locale(identifier: "en_US"), cal.zeroV))
            infoRow("Meredekség", String(format: "%.2f psi/V", locale: Locale(identifier: "en_US"), cal.psiPerV))

            Text("1) Nyomásmentes rendszernél (0 psi) nyomd meg a NULLPONT gombot.\n2) Töltsd fel teljesen ismert nyomásra (pl. régi mérőórád szerint), írd be az értéket, majd nyomd meg a VÉGPONT gombot.")
                .font(.system(size: 11))
                .foregroundColor(AppTheme.textSecondary)
                .lineSpacing(2)

            HStack(spacing: 8) {
                Button(action: onZero) {
                    Text("NULLPONT")
                        .font(.system(size: 11, weight: .bold))
                        .foregroundColor(enabled ? AppTheme.neonBlue : AppTheme.textDisabled)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 10)
                        .overlay(RoundedRectangle(cornerRadius: 8).stroke(enabled ? AppTheme.neonBlue.opacity(0.6) : AppTheme.cardBorder, lineWidth: 1))
                }
                .disabled(!enabled)

                Button(action: onReset) {
                    Text("ALAPÉRTÉK")
                        .font(.system(size: 11, weight: .bold))
                        .foregroundColor(enabled ? AppTheme.authOrange : AppTheme.textDisabled)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 10)
                        .overlay(RoundedRectangle(cornerRadius: 8).stroke(enabled ? AppTheme.authOrange.opacity(0.6) : AppTheme.cardBorder, lineWidth: 1))
                }
                .disabled(!enabled)
            }

            HStack(spacing: 8) {
                TextField("Referencia nyomás (psi)", text: $refText)
                    .keyboardType(.decimalPad)
                    .font(.system(size: 13, weight: .bold))
                    .foregroundColor(AppTheme.textPrimary)
                    .padding(11)
                    .background(AppTheme.darkSurface)
                    .cornerRadius(8)
                    .overlay(RoundedRectangle(cornerRadius: 8).stroke(AppTheme.cardBorder, lineWidth: 1))
                    .disabled(!enabled)

                Button(action: {
                    if let v = refValue {
                        onSpan(v)
                    }
                }) {
                    Text("VÉGPONT")
                        .font(.system(size: 11, weight: .bold))
                        .foregroundColor((enabled && refValid) ? AppTheme.neonGreen : AppTheme.textDisabled)
                        .padding(.horizontal, 16)
                        .padding(.vertical, 12)
                        .background((enabled && refValid) ? AppTheme.neonGreen.opacity(0.2) : AppTheme.darkSurface)
                        .overlay(RoundedRectangle(cornerRadius: 8).stroke((enabled && refValid) ? AppTheme.neonGreen.opacity(0.6) : AppTheme.cardBorder, lineWidth: 1))
                        .cornerRadius(8)
                }
                .disabled(!(enabled && refValid))
            }
        }
        .padding(14)
        .background(AppTheme.cardBackground)
        .overlay(RoundedRectangle(cornerRadius: 12).stroke(AppTheme.cardBorder, lineWidth: 1))
        .cornerRadius(12)
    }

    private func infoRow(_ label: String, _ value: String) -> some View {
        HStack {
            Text(label)
                .font(.system(size: 12))
                .foregroundColor(AppTheme.textSecondary)
            Spacer()
            Text(value)
                .font(.system(size: 12, weight: .bold))
                .foregroundColor(AppTheme.textPrimary)
        }
    }
}

// MARK: - 5. AUTO NYOMÁSTARTÁS

struct AutoHoldSectionView: View {
    @ObservedObject var viewModel: MainViewModel

    private var isAuth: Bool {
        viewModel.connectionState == .authenticated
    }

    private var canUse: Bool {
        isAuth && viewModel.activeDevice != nil
    }

    var body: some View {
        let hold = viewModel.holdState
        let activeIdx = viewModel.activePresetIndex

        ScrollView {
            VStack(alignment: .leading, spacing: 14) {
                Text("AUTOMATA NYOMÁSTARTÁS")
                    .font(.system(size: 13, weight: .black))
                    .tracking(2)
                    .foregroundColor(AppTheme.neonBlue)

                Text("Állítsd be tengelyenként a kívánt nyomást. A bekapcsolt értéket a vezérlő folyamatosan, automatikusan tartja. Egyszerre egy érték lehet aktív; kézi vezérlésnél (nyilak) a nyomástartás azonnal kikapcsol.")
                    .font(.system(size: 12))
                    .foregroundColor(AppTheme.textSecondary)

                // Élő állapot kártya
                VStack(spacing: 8) {
                    HStack {
                        Spacer()
                        liveValueCol("ELSŐ", psi: viewModel.pressures[safe: 0] ?? 0, target: hold.active ? hold.frontPsi : nil)
                        Spacer()
                        liveValueCol("KÖZÖS", psi: viewModel.pressures[safe: 1] ?? 0, target: nil)
                        Spacer()
                        liveValueCol("HÁTSÓ", psi: viewModel.pressures[safe: 2] ?? 0, target: hold.active ? hold.rearPsi : nil)
                        Spacer()
                    }

                    Text(hold.error
                         ? "⚠ A nyomástartást az eszköz leállította (időtúllépés, vagy túlzott nyomáseltérés)."
                         : (hold.active
                            ? "Nyomástartás AKTÍV: \(activeIdx.flatMap { viewModel.presets[safe: $0]?.name } ?? "egyedi érték")"
                            : "Nyomástartás kikapcsolva"))
                        .font(.system(size: 12, weight: .bold))
                        .foregroundColor(hold.error ? AppTheme.neonRed : (hold.active ? AppTheme.neonGreen : AppTheme.textSecondary))
                        .multilineTextAlignment(.center)
                }
                .padding(14)
                .background(AppTheme.cardBackground)
                .overlay(RoundedRectangle(cornerRadius: 12).stroke(hold.active ? AppTheme.neonGreen.opacity(0.6) : AppTheme.cardBorder, lineWidth: 1))
                .cornerRadius(12)

                // 4 db Preset kártya
                ForEach(Array(viewModel.presets.enumerated()), id: \.offset) { index, preset in
                    PresetCardView(
                        index: index,
                        preset: preset,
                        isActive: activeIdx == index,
                        enabled: canUse,
                        onToggle: { turnOn in
                            if turnOn {
                                viewModel.activatePreset(index)
                            } else {
                                viewModel.deactivateHold()
                            }
                        },
                        onSave: { updated in
                            viewModel.savePreset(index: index, preset: updated)
                        }
                    )
                }

                if hold.active {
                    Button(action: { viewModel.deactivateHold() }) {
                        Text("NYOMÁSTARTÁS KIKAPCSOLÁSA")
                            .font(.system(size: 12, weight: .bold))
                            .tracking(1)
                            .foregroundColor(AppTheme.neonRed)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 14)
                            .background(AppTheme.neonRed.opacity(0.18))
                            .overlay(RoundedRectangle(cornerRadius: 10).stroke(AppTheme.neonRed.opacity(0.6), lineWidth: 1))
                            .cornerRadius(10)
                    }
                }
            }
            .padding(16)
        }
    }

    private func liveValueCol(_ label: String, psi: Float, target: Float?) -> some View {
        VStack(spacing: 2) {
            Text(label)
                .font(.system(size: 10, weight: .bold))
                .foregroundColor(AppTheme.textSecondary)
            Text(isAuth ? String(format: "%.1f", locale: Locale(identifier: "en_US"), max(0, psi)) : "--.-")
                .font(.system(size: 20, weight: .black))
                .foregroundColor(isAuth ? AppTheme.neonBlue : AppTheme.textDisabled)
            Text(target != nil ? "cél: \(Int(target!))" : "PSI")
                .font(.system(size: 10))
                .foregroundColor(target != nil ? AppTheme.neonGreen : AppTheme.textSecondary)
        }
    }
}

struct PresetCardView: View {
    let index: Int
    let preset: PressurePreset
    let isActive: Bool
    let enabled: Bool
    let onToggle: (Bool) -> Void
    let onSave: (PressurePreset) -> Void

    @State private var name: String = ""
    @State private var frontText: String = ""
    @State private var rearText: String = ""
    @State private var editingName = false

    private func fmtPsi(_ v: Float) -> String {
        v.truncatingRemainder(dividingBy: 1) == 0 ? "\(Int(v))" : String(format: "%.1f", locale: Locale(identifier: "en_US"), v)
    }

    private func parsePsi(_ s: String) -> Float? {
        Float(s.trimmingCharacters(in: .whitespaces).replacingOccurrences(of: ",", with: "."))
    }

    var body: some View {
        let front = parsePsi(frontText)
        let rear = parsePsi(rearText)
        let valid = (front != nil && rear != nil &&
                     front! >= 0 && front! <= PressurePreset.maxPsi &&
                     rear! >= 0 && rear! <= PressurePreset.maxPsi &&
                     !name.trimmingCharacters(in: .whitespaces).isEmpty)
        let dirty = (name != preset.name || front != preset.frontPsi || rear != preset.rearPsi)

        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Text("#\(index + 1)")
                    .font(.system(size: 11, weight: .bold))
                    .foregroundColor(AppTheme.neonBlue)
                    .padding(.horizontal, 8)
                    .padding(.vertical, 4)
                    .background(AppTheme.darkSurface)
                    .cornerRadius(6)

                if editingName {
                    TextField("Név", text: $name)
                        .font(.system(size: 14, weight: .bold))
                        .foregroundColor(AppTheme.textPrimary)
                        .padding(6)
                        .background(AppTheme.darkSurface)
                        .cornerRadius(6)
                    Button(action: { editingName = false }) {
                        Image(systemName: "checkmark")
                            .foregroundColor(AppTheme.neonGreen)
                    }
                } else {
                    Text(name)
                        .font(.system(size: 15, weight: .bold))
                        .foregroundColor(AppTheme.textPrimary)
                    Spacer()
                    Button(action: { editingName = true }) {
                        Image(systemName: "pencil")
                            .font(.system(size: 14))
                            .foregroundColor(AppTheme.textSecondary)
                    }
                }

                if isActive {
                    Text("AKTÍV")
                        .font(.system(size: 11, weight: .black))
                        .foregroundColor(AppTheme.neonGreen)
                        .padding(.horizontal, 10)
                        .padding(.vertical, 4)
                        .background(AppTheme.neonGreen.opacity(0.2))
                        .cornerRadius(6)
                }
            }

            HStack(spacing: 10) {
                VStack(alignment: .leading, spacing: 4) {
                    Text("Első tengely (psi)")
                        .font(.system(size: 11))
                        .foregroundColor(AppTheme.textSecondary)
                    TextField("65", text: $frontText)
                        .keyboardType(.decimalPad)
                        .font(.system(size: 14, weight: .bold))
                        .foregroundColor(AppTheme.textPrimary)
                        .padding(10)
                        .background(AppTheme.darkSurface)
                        .cornerRadius(8)
                        .overlay(RoundedRectangle(cornerRadius: 8).stroke(AppTheme.cardBorder, lineWidth: 1))
                }

                VStack(alignment: .leading, spacing: 4) {
                    Text("Hátsó tengely (psi)")
                        .font(.system(size: 11))
                        .foregroundColor(AppTheme.textSecondary)
                    TextField("52", text: $rearText)
                        .keyboardType(.decimalPad)
                        .font(.system(size: 14, weight: .bold))
                        .foregroundColor(AppTheme.textPrimary)
                        .padding(10)
                        .background(AppTheme.darkSurface)
                        .cornerRadius(8)
                        .overlay(RoundedRectangle(cornerRadius: 8).stroke(AppTheme.cardBorder, lineWidth: 1))
                }
            }

            if dirty {
                Button(action: {
                    if valid, let f = front, let r = rear {
                        onSave(PressurePreset(id: index, name: name.trimmingCharacters(in: .whitespaces), frontPsi: f, rearPsi: r))
                    }
                }) {
                    HStack(spacing: 6) {
                        Image(systemName: "square.and.arrow.down")
                        Text("MÓDOSÍTÁS MENTÉSE")
                            .font(.system(size: 12, weight: .bold))
                    }
                    .foregroundColor(valid ? AppTheme.authOrange : AppTheme.textDisabled)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 10)
                    .background(AppTheme.authOrange.opacity(0.2))
                    .overlay(RoundedRectangle(cornerRadius: 8).stroke(AppTheme.authOrange.opacity(0.6), lineWidth: 1))
                    .cornerRadius(8)
                }
                .disabled(!valid)
            }

            Button(action: { onToggle(!isActive) }) {
                HStack(spacing: 8) {
                    Image(systemName: isActive ? "power.circle.fill" : "power.circle")
                        .font(.system(size: 20))
                    Text(dirty
                         ? "Mentsd el előbb a módosítást"
                         : (isActive ? "BEKAPCSOLVA – érintsd meg a kikapcsoláshoz" : "KIKAPCSOLVA – érintsd meg a bekapcsoláshoz"))
                        .font(.system(size: 12, weight: .semibold))
                }
                .foregroundColor(isActive ? AppTheme.neonGreen : AppTheme.textPrimary)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 13)
                .background(isActive ? AppTheme.neonGreen.opacity(0.18) : AppTheme.darkSurface)
                .overlay(RoundedRectangle(cornerRadius: 10).stroke(isActive ? AppTheme.neonGreen.opacity(0.6) : AppTheme.cardBorder, lineWidth: 1.5))
                .cornerRadius(10)
            }
            .disabled(!enabled || dirty)
        }
        .padding(14)
        .background(isActive ? AppTheme.neonGreen.opacity(0.05) : AppTheme.cardBackground)
        .overlay(RoundedRectangle(cornerRadius: 12).stroke(isActive ? AppTheme.neonGreen.opacity(0.7) : AppTheme.cardBorder, lineWidth: isActive ? 1.5 : 1))
        .cornerRadius(12)
        .onAppear {
            name = preset.name
            frontText = fmtPsi(preset.frontPsi)
            rearText = fmtPsi(preset.rearPsi)
        }
        .onChange(of: preset) { p in
            name = p.name
            frontText = fmtPsi(p.frontPsi)
            rearText = fmtPsi(p.rearPsi)
        }
    }
}

// MARK: - 6. INFO SZEKCIÓ

struct InfoSectionView: View {
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 14) {
                VStack(alignment: .leading, spacing: 12) {
                    Text("Toth Works air ride remote system")
                        .font(.system(size: 16, weight: .black))
                        .foregroundColor(AppTheme.neonBlue)
                        .frame(maxWidth: .infinity, alignment: .center)

                    Divider().background(AppTheme.cardBorder)

                    HStack {
                        VStack(alignment: .leading) {
                            Text("Készítette:")
                                .font(.system(size: 11))
                                .foregroundColor(AppTheme.textSecondary)
                            Text("Lizi Design - Barni")
                                .font(.system(size: 13, weight: .bold))
                                .foregroundColor(AppTheme.textPrimary)
                        }
                        Spacer()
                        VStack(alignment: .trailing) {
                            Text("Forgalmazó:")
                                .font(.system(size: 11))
                                .foregroundColor(AppTheme.textSecondary)
                            Text("TOTH WORKS")
                                .font(.system(size: 13, weight: .black))
                                .foregroundColor(AppTheme.neonCyan)
                        }
                    }

                    Divider().background(AppTheme.cardBorder)

                    Text("ÁSZF ÉS FELHASZNÁLÁSI TUDNIVALÓK")
                        .font(.system(size: 12, weight: .black))
                        .foregroundColor(AppTheme.neonCyan)

                    Text("""
ASZF: A készüléket verseny célra és egyéni magánszemélyek szenvédélyből történő tuning építések kiegészítésére ajánljuk. A készülék és az applikáció semilyen személyes adatot nem tárol, vagy használ fel! A készülék és az applikáció is aktív tesztelésen esett át (stressz teszt) így kereskedelmi forgalomba hozható struktúrális egységet képez. Minden felhasznált anyag és alkatrész MAGYAR beszállítóktól származik.

A termék bekötése egyszerű, lentebb található rajz alapján bárki bekötheti a meglévő rendszere, világításai kapcsolójával párhuzamosan, vagy azok helyett.

A termék bekötéséből és használatából adódó eszközök károsodásáért a fejlesztőt és az eszköz beszerelését végző személy nem vonható felelősségre. A termék kizárólag 1-12v max 10A kapcsolását teszi lehetővé. Belső feszültségét galvanikus leválasztás miatt a kapcsolók irányába kivezetni nem lehet. A készülék helytelen bekötésére garanciális javítás nem alkalmazható! Az alaplapján külön részegység felel a fordított polaritás miatti meghibásodás jelzésére.

Garanciális javítás a fejlesztőnél lehetséges: 7400, Kaposvár Vak Bottyán utca 64. info@4k2k.hu.

Sok örömteli kilómétert és rengeteg csodálkozó arcot kíván a TOTH WORKS és a Lizi Design csapata.
""")
                        .font(.system(size: 12))
                        .foregroundColor(AppTheme.textPrimary)
                        .lineSpacing(4)
                }
                .padding(16)
                .background(AppTheme.cardBackground)
                .overlay(RoundedRectangle(cornerRadius: 12).stroke(AppTheme.cardBorder, lineWidth: 1))
                .cornerRadius(12)

                // Bekötési rajz kártya
                VStack(alignment: .leading, spacing: 10) {
                    Text("BEKÖTÉSI RAJZ & KAPCSOLÁSI SÉMA")
                        .font(.system(size: 12, weight: .black))
                        .foregroundColor(AppTheme.neonCyan)

                    if UIImage(named: "conn_logo") != nil {
                        Image("conn_logo")
                            .resizable()
                            .scaledToFit()
                            .cornerRadius(8)
                    }

                    Text("R1 Első tengely FEL • R2 Első tengely LE\nR3 Hátsó tengely FEL • R4 Hátsó tengely LE\nA0 Nyomásérzékelő: első tengely\nA1 Nyomásérzékelő: közös / tartály\nA2 Nyomásérzékelő: hátsó tengely")
                        .font(.system(size: 11, weight: .medium))
                        .foregroundColor(AppTheme.textSecondary)
                        .lineSpacing(3)
                }
                .padding(16)
                .background(AppTheme.cardBackground)
                .overlay(RoundedRectangle(cornerRadius: 12).stroke(AppTheme.cardBorder, lineWidth: 1))
                .cornerRadius(12)

                // Tanúsítványok
                VStack(spacing: 8) {
                    Text("ROHS - CE - BLUETOOTH - WIFI - ESP- \"2025\"")
                        .font(.system(size: 12, weight: .black))
                        .tracking(1)
                        .foregroundColor(AppTheme.neonBlue)
                }
                .frame(maxWidth: .infinity)
                .padding(14)
                .background(AppTheme.cardBackground)
                .overlay(RoundedRectangle(cornerRadius: 12).stroke(AppTheme.cardBorder, lineWidth: 1))
                .cornerRadius(12)
            }
            .padding(16)
        }
    }
}

// MARK: - Segéd Sheet-ek (PIN csere & Új eszköz csatlakozás)

struct DeviceChangePinSheet: View {
    let device: SavedDevice
    @ObservedObject var viewModel: MainViewModel
    let onDismiss: () -> Void

    @State private var newPin = ""
    @State private var useMaster = false
    @State private var masterPw = ""

    var body: some View {
        ZStack {
            AppTheme.deepBlack.ignoresSafeArea()
            VStack(spacing: 14) {
                Text("PIN MÓDOSÍTÁS – \(device.name)")
                    .font(.system(size: 15, weight: .black))
                    .foregroundColor(AppTheme.neonBlue)

                SecureField("Új 4 jegyű PIN", text: $newPin)
                    .keyboardType(.numberPad)
                    .padding(12)
                    .background(AppTheme.cardBackground)
                    .foregroundColor(AppTheme.textPrimary)
                    .cornerRadius(8)
                    .onChange(of: newPin) { val in
                        newPin = String(val.filter { $0.isNumber }.prefix(4))
                    }

                Toggle("Mesterjelszó használata", isOn: $useMaster)
                    .font(.system(size: 12))
                    .foregroundColor(AppTheme.textSecondary)
                    .tint(AppTheme.authOrange)

                if useMaster {
                    SecureField("Mesterjelszó", text: $masterPw)
                        .padding(12)
                        .background(AppTheme.cardBackground)
                        .foregroundColor(AppTheme.textPrimary)
                        .cornerRadius(8)
                }

                HStack(spacing: 12) {
                    Button("MÉGSE", action: onDismiss)
                        .font(.system(size: 13, weight: .bold))
                        .foregroundColor(AppTheme.textSecondary)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 12)
                        .background(AppTheme.cardBackground)
                        .cornerRadius(8)

                    Button("MENTÉS") {
                        if newPin.count == 4 {
                            if useMaster {
                                viewModel.authenticateMaster(masterPw)
                            }
                            viewModel.changePin(newPin)
                            onDismiss()
                        }
                    }
                    .font(.system(size: 13, weight: .bold))
                    .foregroundColor(AppTheme.deepBlack)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 12)
                    .background(newPin.count == 4 ? AppTheme.neonBlue : AppTheme.textDisabled)
                    .cornerRadius(8)
                }
            }
            .padding(24)
        }
        .presentationDetents([.height(310)])
    }
}

struct ConnectScannedPinSheet: View {
    let scanned: ScannedDevice
    @Binding var pinInput: String
    @Binding var savePin: Bool
    let onConnect: () -> Void
    let onCancel: () -> Void

    var body: some View {
        ZStack {
            AppTheme.deepBlack.ignoresSafeArea()
            VStack(spacing: 16) {
                Text(scanned.name)
                    .font(.system(size: 16, weight: .black))
                    .foregroundColor(AppTheme.neonBlue)

                SecureField("4 jegyű PIN (alapértelmezett: 1234)", text: $pinInput)
                    .keyboardType(.numberPad)
                    .padding(12)
                    .background(AppTheme.cardBackground)
                    .foregroundColor(AppTheme.textPrimary)
                    .cornerRadius(8)
                    .overlay(RoundedRectangle(cornerRadius: 8).stroke(AppTheme.neonBlue, lineWidth: 1))
                    .onChange(of: pinInput) { val in
                        pinInput = String(val.filter { $0.isNumber }.prefix(4))
                    }

                Toggle("PIN mentése ehhez az eszközhöz", isOn: $savePin)
                    .font(.system(size: 12))
                    .foregroundColor(AppTheme.textSecondary)
                    .tint(AppTheme.neonBlue)

                HStack(spacing: 12) {
                    Button("MÉGSE", action: onCancel)
                        .font(.system(size: 13, weight: .bold))
                        .foregroundColor(AppTheme.textSecondary)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 12)
                        .background(AppTheme.cardBackground)
                        .cornerRadius(8)

                    Button("CSATLAKOZÁS") {
                        if pinInput.count == 4 {
                            onConnect()
                        }
                    }
                    .font(.system(size: 13, weight: .bold))
                    .foregroundColor(AppTheme.deepBlack)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 12)
                    .background(pinInput.count == 4 ? AppTheme.neonGreen : AppTheme.textDisabled)
                    .cornerRadius(8)
                }
            }
            .padding(24)
        }
        .presentationDetents([.height(280)])
    }
}
