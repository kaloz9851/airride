import Foundation
import CoreBluetooth

final class BleManager: NSObject, ObservableObject, CBCentralManagerDelegate, CBPeripheralDelegate {

    static let serviceUUID = CBUUID(string: "6E400001-B5A3-F393-E0A9-E50E24DCCA9E")
    static let rxCharUUID  = CBUUID(string: "6E400002-B5A3-F393-E0A9-E50E24DCCA9E")
    static let txCharUUID  = CBUUID(string: "6E400003-B5A3-F393-E0A9-E50E24DCCA9E")
    static let bleNamePrefix = "TothWorks Air Ride"

    @Published private(set) var connectionState: BleConnectionState = .disconnected
    @Published private(set) var statusMessage: String = ""
    @Published private(set) var relayStates: [Bool] = [false, false, false, false, false, false]
    @Published private(set) var scannedDevices: [ScannedDevice] = []
    @Published private(set) var connectedDeviceId: String? = nil

    private var centralManager: CBCentralManager!
    private var discoveredPeripherals: [String: CBPeripheral] = [:]
    private var activePeripheral: CBPeripheral?
    private var rxChar: CBCharacteristic?
    private var txChar: CBCharacteristic?

    private var pendingPin: String?
    private var autoDevices: [String: String?] = [:]
    private var isAutoScanning = false
    private var scanStopWorkItem: DispatchWorkItem?
    private var commandQueue: [String] = []
    private var queueTimer: Timer?

    override init() {
        super.init()
        centralManager = CBCentralManager(delegate: self, queue: .main)
        queueTimer = Timer.scheduledTimer(withTimeInterval: 0.065, repeats: true) { [weak self] _ in
            self?.flushNextQueuedCommand()
        }
    }

    deinit {
        queueTimer?.invalidate()
    }

    // MARK: - CBCentralManagerDelegate

    func centralManagerDidUpdateState(_ central: CBCentralManager) {
        if central.state == .poweredOn {
            if !autoDevices.isEmpty && connectionState == .disconnected {
                startAutoScan(devices: autoDevices)
            }
        } else {
            connectionState = .disconnected
            activePeripheral = nil
            rxChar = nil
            txChar = nil
        }
    }

    func centralManager(_ central: CBCentralManager,
                        didDiscover peripheral: CBPeripheral,
                        advertisementData: [String: Any],
                        rssi RSSI: NSNumber) {
        let advName = advertisementData[CBAdvertisementDataLocalNameKey] as? String
        let name = advName ?? peripheral.name ?? ""
        let id = peripheral.identifier.uuidString

        discoveredPeripherals[id] = peripheral

        if isAutoScanning {
            if autoDevices.keys.contains(id) && connectionState == .scanning {
                stopScan()
                connectedDeviceId = id
                connect(deviceId: id, pin: autoDevices[id] ?? nil)
                return
            }
        }

        guard name.hasPrefix(Self.bleNamePrefix) else { return }
        let item = ScannedDevice(id: id, name: name, rssi: RSSI.intValue)
        if let idx = scannedDevices.firstIndex(where: { $0.id == id }) {
            scannedDevices[idx] = item
        } else {
            scannedDevices.append(item)
        }
    }

    func centralManager(_ central: CBCentralManager, didConnect peripheral: CBPeripheral) {
        connectionState = .connected
        connectedDeviceId = peripheral.identifier.uuidString
        peripheral.delegate = self
        peripheral.discoverServices([Self.serviceUUID])
    }

    func centralManager(_ central: CBCentralManager, didFailToConnect peripheral: CBPeripheral, error: Error?) {
        connectionState = .error
        activePeripheral = nil
        rxChar = nil
        txChar = nil
    }

    func centralManager(_ central: CBCentralManager, didDisconnectPeripheral peripheral: CBPeripheral, error: Error?) {
        connectionState = .disconnected
        statusMessage = "DISCONNECTED"
        relayStates = [false, false, false, false, false, false]
        rxChar = nil
        txChar = nil
        activePeripheral = nil

        if !autoDevices.isEmpty {
            DispatchQueue.main.asyncAfter(deadline: .now() + 3.0) { [weak self] in
                guard let self = self, self.connectionState == .disconnected else { return }
                self.startAutoScan(devices: self.autoDevices)
            }
        }
    }

    // MARK: - CBPeripheralDelegate

    func peripheral(_ peripheral: CBPeripheral, didDiscoverServices error: Error?) {
        guard error == nil,
              let services = peripheral.services,
              let uartService = services.first(where: { $0.uuid == Self.serviceUUID }) else {
            connectionState = .error
            return
        }
        peripheral.discoverCharacteristics([Self.rxCharUUID, Self.txCharUUID], for: uartService)
    }

    func peripheral(_ peripheral: CBPeripheral, didDiscoverCharacteristicsFor service: CBService, error: Error?) {
        guard error == nil, let chars = service.characteristics else {
            connectionState = .error
            return
        }
        for c in chars {
            if c.uuid == Self.rxCharUUID { rxChar = c }
            if c.uuid == Self.txCharUUID { txChar = c }
        }
        guard let tx = txChar, rxChar != nil else {
            connectionState = .error
            return
        }
        peripheral.setNotifyValue(true, for: tx)
    }

    func peripheral(_ peripheral: CBPeripheral, didUpdateNotificationStateFor characteristic: CBCharacteristic, error: Error?) {
        guard characteristic.uuid == Self.txCharUUID else { return }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.35) { [weak self] in
            guard let self = self else { return }
            self.connectionState = .authenticating
            if let pin = self.pendingPin, !pin.isEmpty {
                self.writeWithResponse("AUTH:\(pin)")
            }
        }
    }

    func peripheral(_ peripheral: CBPeripheral, didUpdateValueFor characteristic: CBCharacteristic, error: Error?) {
        guard error == nil,
              let data = characteristic.value,
              let msg = String(data: data, encoding: .utf8) else { return }
        handleEsp32Message(msg.trimmingCharacters(in: .whitespacesAndNewlines))
    }

    // MARK: - ESP32 Protokoll feldolgozás

    private func handleEsp32Message(_ msg: String) {
        statusMessage = msg
        switch msg {
        case "AUTH_OK", "MASTER_AUTH_OK":
            connectionState = .authenticated
            enqueueCommand("STATUS")

        case "AUTH_FAIL", "MASTER_AUTH_FAIL":
            pendingPin = nil
            connectionState = .connected

        case _ where msg.hasPrefix("R:") && msg.count >= 4:
            let parsed = msg.dropFirst(2).map { $0 == "1" }
            var full = [false, false, false, false, false, false]
            for i in 0..<min(6, parsed.count) {
                full[i] = parsed[i]
            }
            relayStates = full

        default:
            break
        }
    }

    // MARK: - BLE Írások

    private func writeWithResponse(_ cmd: String) {
        guard let p = activePeripheral, let rx = rxChar, let data = cmd.data(using: .utf8) else { return }
        let writeType: CBCharacteristicWriteType = rx.properties.contains(.write) ? .withResponse : .withoutResponse
        p.writeValue(data, for: rx, type: writeType)
    }

    private func writeWithoutResponse(_ cmd: String) {
        guard connectionState == .authenticated,
              let p = activePeripheral,
              let rx = rxChar,
              let data = cmd.data(using: .utf8) else { return }
        let writeType: CBCharacteristicWriteType = rx.properties.contains(.writeWithoutResponse) ? .withoutResponse : .withResponse
        p.writeValue(data, for: rx, type: writeType)
    }

    private func enqueueCommand(_ cmd: String) {
        commandQueue.append(cmd)
    }

    private func flushNextQueuedCommand() {
        guard connectionState == .authenticated, !commandQueue.isEmpty else { return }
        let cmd = commandQueue.removeFirst()
        writeWithoutResponse(cmd)
    }

    // MARK: - Publikus vezérlő függvények

    func startScan() {
        guard centralManager.state == .poweredOn else { return }
        scanStopWorkItem?.cancel()
        isAutoScanning = false
        scannedDevices = []
        connectionState = .scanning
        centralManager.scanForPeripherals(withServices: nil, options: [CBCentralManagerScanOptionAllowDuplicatesKey: true])

        let work = DispatchWorkItem { [weak self] in
            self?.stopScan()
        }
        scanStopWorkItem = work
        DispatchQueue.main.asyncAfter(deadline: .now() + 10.0, execute: work)
    }

    func startAutoScan(devices: [String: String?]) {
        autoDevices = devices
        guard !devices.isEmpty, centralManager.state == .poweredOn else { return }
        let uuids = devices.keys.compactMap { UUID(uuidString: $0) }
        let known = centralManager.retrievePeripherals(withIdentifiers: uuids)
        if let first = known.first {
            let id = first.identifier.uuidString
            discoveredPeripherals[id] = first
            connectedDeviceId = id
            connect(deviceId: id, pin: devices[id] ?? nil)
            return
        }

        isAutoScanning = true
        connectionState = .scanning
        centralManager.scanForPeripherals(withServices: [Self.serviceUUID], options: nil)
    }

    func stopScan() {
        scanStopWorkItem?.cancel()
        centralManager.stopScan()
        isAutoScanning = false
        if connectionState == .scanning {
            connectionState = .disconnected
        }
    }

    func connect(deviceId: String, pin: String?) {
        stopScan()
        pendingPin = pin
        if discoveredPeripherals[deviceId] == nil, let uuid = UUID(uuidString: deviceId) {
            if let retrieved = centralManager.retrievePeripherals(withIdentifiers: [uuid]).first {
                discoveredPeripherals[deviceId] = retrieved
            }
        }
        guard let peripheral = discoveredPeripherals[deviceId] else {
            connectionState = .error
            return
        }
        activePeripheral = peripheral
        connectionState = .connecting
        centralManager.connect(peripheral, options: nil)
    }

    func disconnect() {
        scanStopWorkItem?.cancel()
        autoDevices = [:]
        pendingPin = nil
        commandQueue.removeAll()
        if let p = activePeripheral {
            centralManager.cancelPeripheralConnection(p)
        }
        connectionState = .disconnected
    }

    func authenticate(pin: String) {
        pendingPin = pin
        connectionState = .authenticating
        writeWithResponse("AUTH:\(pin)")
    }

    func sendMasterAuth(masterPassword: String) {
        writeWithResponse("AUTH_MASTER:\(masterPassword)")
    }

    func changePin(_ newPin: String) {
        writeWithoutResponse("SET_PIN:\(newPin)")
    }

    func setRelay(index: Int, on: Bool) {
        writeWithoutResponse("R\(index + 1):\(on ? "ON" : "OFF")")
    }

    func setRelayCombo(_ combo: String, on: Bool) {
        writeWithoutResponse("R\(combo):\(on ? "ON" : "OFF")")
    }

    func toggleRelay(index: Int) {
        writeWithoutResponse("R\(index + 1):TOGGLE")
    }

    func requestStatus() {
        enqueueCommand("STATUS")
    }
}
