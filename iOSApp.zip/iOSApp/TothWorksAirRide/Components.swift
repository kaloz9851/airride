import SwiftUI

enum ArrowDirection {
    case up
    case down
}

// MARK: - Carbon Fiber háttér minta

struct CarbonFiberBackground: View {
    var body: some View {
        Canvas { context, size in
            context.fill(Path(CGRect(origin: .zero, size: size)), with: .color(AppTheme.deepBlack))
            let step: CGFloat = 12
            let lightColor = Color.white.opacity(0.018)
            var y: CGFloat = 0
            while y < size.height {
                var x: CGFloat = 0
                while x < size.width {
                    let rect = CGRect(x: x, y: y, width: step / 2, height: step / 2)
                    context.fill(Path(rect), with: .color(lightColor))
                    let rect2 = CGRect(x: x + step / 2, y: y + step / 2, width: step / 2, height: step / 2)
                    context.fill(Path(rect2), with: .color(lightColor))
                    x += step
                }
                y += step
            }
        }
        .ignoresSafeArea()
    }
}

// MARK: - Kapcsolat státusz badge

struct ConnectionStatusBadge: View {
    let state: BleConnectionState
    let deviceName: String

    @State private var pulse = false

    private var badgeInfo: (String, Color) {
        switch state {
        case .authenticated:
            let short = deviceName.replacingOccurrences(of: "TothWorks Air Ride ", with: "")
            return (short.isEmpty ? "AKTÍV" : short, AppTheme.neonGreen)
        case .authenticating:
            return ("PIN...", AppTheme.authOrange)
        case .connecting, .connected:
            return ("CSATL...", AppTheme.neonBlue)
        case .scanning:
            return ("KERESÉS", AppTheme.neonCyan)
        case .error:
            return ("HIBA", AppTheme.neonRed)
        case .disconnected:
            return ("OFFLINE", AppTheme.textSecondary)
        }
    }

    var body: some View {
        let (label, color) = badgeInfo
        HStack(spacing: 6) {
            Circle()
                .fill(color)
                .frame(width: 8, height: 8)
                .shadow(color: color.opacity(0.8), radius: 4)
                .opacity(state == .authenticated && pulse ? 0.35 : 1.0)
                .onAppear {
                    withAnimation(.easeInOut(duration: 1.4).repeatForever(autoreverses: true)) {
                        pulse = true
                    }
                }
            Text(label)
                .font(.system(size: 10, weight: .bold))
                .foregroundColor(color)
                .lineLimit(1)
        }
        .padding(.horizontal, 9)
        .padding(.vertical, 5)
        .background(color.opacity(0.10))
        .overlay(
            RoundedRectangle(cornerRadius: 12)
                .stroke(color.opacity(0.45), lineWidth: 1)
        )
        .cornerRadius(12)
    }
}

// MARK: - Autó animáció (car_logo.png + emelés és dőlés)

struct CarView: View {
    let frontHeight: Float
    let rearHeight: Float

    var body: some View {
        let avgLift = CGFloat((frontHeight + rearHeight) / 2.0)
        let tiltDeg = Double((frontHeight - rearHeight) * 10.0)
        let maxLiftPts: CGFloat = 44.0

        ZStack {
            if avgLift > 0.05 {
                Ellipse()
                    .fill(
                        RadialGradient(
                            colors: [AppTheme.neonBlue.opacity(Double(avgLift) * 0.38), .clear],
                            center: .center,
                            startRadius: 5,
                            endRadius: 140
                        )
                    )
                    .frame(height: 28)
                    .offset(y: 52)
            }

            if UIImage(named: "car_logo") != nil {
                Image("car_logo")
                    .resizable()
                    .scaledToFit()
                    .padding(.horizontal, 6)
                    .offset(y: -(avgLift - 0.35) * maxLiftPts)
                    .rotationEffect(.degrees(tiltDeg))
                    .animation(.interpolatingSpring(stiffness: 180, damping: 18), value: frontHeight)
                    .animation(.interpolatingSpring(stiffness: 180, damping: 18), value: rearHeight)
            } else {
                FallbackCarShape()
                    .fill(
                        LinearGradient(
                            colors: [Color(red: 0.12, green: 0.17, blue: 0.27), Color(red: 0.04, green: 0.06, blue: 0.12)],
                            startPoint: .top,
                            endPoint: .bottom
                        )
                    )
                    .overlay(FallbackCarShape().stroke(AppTheme.neonBlue, lineWidth: 1.5))
                    .frame(height: 95)
                    .offset(y: -(avgLift - 0.35) * maxLiftPts)
                    .rotationEffect(.degrees(tiltDeg))
            }
        }
    }
}

struct FallbackCarShape: Shape {
    func path(in rect: CGRect) -> Path {
        var p = Path()
        let w = rect.width
        let h = rect.height
        p.move(to: CGPoint(x: w * 0.08, y: h * 0.78))
        p.addLine(to: CGPoint(x: w * 0.92, y: h * 0.78))
        p.addLine(to: CGPoint(x: w * 0.89, y: h * 0.50))
        p.addLine(to: CGPoint(x: w * 0.76, y: h * 0.44))
        p.addLine(to: CGPoint(x: w * 0.65, y: h * 0.22))
        p.addLine(to: CGPoint(x: w * 0.30, y: h * 0.25))
        p.addLine(to: CGPoint(x: w * 0.20, y: h * 0.48))
        p.addLine(to: CGPoint(x: w * 0.09, y: h * 0.54))
        p.closeSubpath()
        return p
    }
}

struct GroundLine: View {
    var body: some View {
        Rectangle()
            .fill(
                LinearGradient(
                    colors: [
                        .clear,
                        AppTheme.neonBlue.opacity(0.5),
                        AppTheme.neonCyan.opacity(0.85),
                        AppTheme.neonBlue.opacity(0.5),
                        .clear
                    ],
                    startPoint: .leading,
                    endPoint: .trailing
                )
            )
            .frame(height: 2)
            .padding(.horizontal, 32)
    }
}

// MARK: - Animált Nyíl Gomb (Press & Hold)

struct ArrowShape: Shape {
    let direction: ArrowDirection

    func path(in rect: CGRect) -> Path {
        var p = Path()
        let w = rect.width
        let h = rect.height
        if direction == .up {
            p.move(to: CGPoint(x: w * 0.50, y: h * 0.08))
            p.addLine(to: CGPoint(x: w * 0.90, y: h * 0.52))
            p.addLine(to: CGPoint(x: w * 0.67, y: h * 0.52))
            p.addLine(to: CGPoint(x: w * 0.67, y: h * 0.92))
            p.addLine(to: CGPoint(x: w * 0.33, y: h * 0.92))
            p.addLine(to: CGPoint(x: w * 0.33, y: h * 0.52))
            p.addLine(to: CGPoint(x: w * 0.10, y: h * 0.52))
            p.closeSubpath()
        } else {
            p.move(to: CGPoint(x: w * 0.50, y: h * 0.92))
            p.addLine(to: CGPoint(x: w * 0.90, y: h * 0.48))
            p.addLine(to: CGPoint(x: w * 0.67, y: h * 0.48))
            p.addLine(to: CGPoint(x: w * 0.67, y: h * 0.08))
            p.addLine(to: CGPoint(x: w * 0.33, y: h * 0.08))
            p.addLine(to: CGPoint(x: w * 0.33, y: h * 0.48))
            p.addLine(to: CGPoint(x: w * 0.10, y: h * 0.48))
            p.closeSubpath()
        }
        return p
    }
}

struct ArrowButton: View {
    let direction: ArrowDirection
    let size: CGFloat
    let color: Color
    let isEnabled: Bool
    let onPress: () -> Void
    let onRelease: () -> Void

    @State private var isPressed = false
    @State private var glowPulse = false

    var body: some View {
        ZStack {
            Circle()
                .fill(color.opacity(isPressed ? 0.42 : (glowPulse ? 0.18 : 0.06)))
                .frame(width: size * (glowPulse ? 1.02 : 0.88), height: size * (glowPulse ? 1.02 : 0.88))
                .blur(radius: isPressed ? 10 : 4)

            ArrowShape(direction: direction)
                .fill(
                    isPressed
                    ? LinearGradient(colors: [.white, AppTheme.neonCyan], startPoint: .top, endPoint: .bottom)
                    : LinearGradient(colors: [color, color.opacity(0.55)], startPoint: .top, endPoint: .bottom)
                )
                .overlay(
                    ArrowShape(direction: direction)
                        .stroke(isPressed ? Color.white : color.opacity(0.85), lineWidth: 1.6)
                )
                .shadow(color: isPressed ? color : .black.opacity(0.5), radius: isPressed ? 14 : 5)
                .padding(8)
        }
        .frame(width: size, height: size)
        .scaleEffect(isPressed ? 0.88 : 1.0)
        .animation(.spring(response: 0.22, dampingFraction: 0.6), value: isPressed)
        .contentShape(Rectangle())
        .gesture(
            DragGesture(minimumDistance: 0)
                .onChanged { _ in
                    guard isEnabled else { return }
                    if !isPressed {
                        isPressed = true
                        onPress()
                    }
                }
                .onEnded { _ in
                    if isPressed {
                        isPressed = false
                        onRelease()
                    }
                }
        )
        .onAppear {
            withAnimation(.easeInOut(duration: 2.0).repeatForever(autoreverses: true)) {
                glowPulse = true
            }
        }
        .onChange(of: isEnabled) { enabled in
            if !enabled && isPressed {
                isPressed = false
                onRelease()
            }
        }
    }
}

// MARK: - Kombó Gomb (▲ MIND FEL ▲ / ▼ MIND LE ▼)

struct ComboActionButton: View {
    let label: String
    let color: Color
    let isEnabled: Bool
    let onPress: () -> Void
    let onRelease: () -> Void

    @State private var isPressed = false

    var body: some View {
        Text(label)
            .font(.system(size: 12, weight: .bold))
            .tracking(1.0)
            .foregroundColor(isEnabled ? (isPressed ? .white : color) : AppTheme.textDisabled)
            .padding(.horizontal, 18)
            .padding(.vertical, 14)
            .frame(maxWidth: .infinity)
            .background(
                RoundedRectangle(cornerRadius: 24)
                    .fill(color.opacity(isPressed ? 0.38 : 0.08))
            )
            .overlay(
                RoundedRectangle(cornerRadius: 24)
                    .stroke(
                        LinearGradient(
                            colors: [color.opacity(0.65), AppTheme.neonBlue.opacity(0.45)],
                            startPoint: .leading,
                            endPoint: .trailing
                        ),
                        lineWidth: 1.5
                    )
            )
            .shadow(color: isPressed ? color.opacity(0.7) : .clear, radius: 12)
            .scaleEffect(isPressed ? 0.93 : 1.0)
            .animation(.spring(response: 0.22, dampingFraction: 0.6), value: isPressed)
            .contentShape(Rectangle())
            .gesture(
                DragGesture(minimumDistance: 0)
                    .onChanged { _ in
                        guard isEnabled else { return }
                        if !isPressed {
                            isPressed = true
                            onPress()
                        }
                    }
                    .onEnded { _ in
                        if isPressed {
                            isPressed = false
                            onRelease()
                        }
                    }
            )
            .onChange(of: isEnabled) { enabled in
                if !enabled && isPressed {
                    isPressed = false
                    onRelease()
                }
            }
    }
}
