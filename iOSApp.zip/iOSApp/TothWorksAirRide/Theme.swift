import SwiftUI

enum AppTheme {
    static let deepBlack       = Color(red: 0x09/255.0, green: 0x0B/255.0, blue: 0x10/255.0)
    static let darkSurface     = Color(red: 0x0F/255.0, green: 0x12/255.0, blue: 0x18/255.0)
    static let cardBackground  = Color(red: 0x15/255.0, green: 0x1A/255.0, blue: 0x23/255.0)
    static let cardBorder      = Color(red: 0x1E/255.0, green: 0x26/255.0, blue: 0x35/255.0)

    static let neonBlue        = Color(red: 0x00/255.0, green: 0xBF/255.0, blue: 0xFF/255.0)
    static let neonCyan        = Color(red: 0x00/255.0, green: 0xFF/255.0, blue: 0xEA/255.0)
    static let neonGreen       = Color(red: 0x39/255.0, green: 0xFF/255.0, blue: 0x14/255.0)
    static let authOrange      = Color(red: 0xFF/255.0, green: 0xAB/255.0, blue: 0x00/255.0)
    static let neonRed         = Color(red: 0xFF/255.0, green: 0x17/255.0, blue: 0x44/255.0)

    static let textPrimary     = Color(red: 0xEC/255.0, green: 0xEF/255.0, blue: 0xF1/255.0)
    static let textSecondary   = Color(red: 0x78/255.0, green: 0x90/255.0, blue: 0x9C/255.0)
    static let textDisabled    = Color(red: 0x45/255.0, green: 0x5A/255.0, blue: 0x64/255.0)
}
