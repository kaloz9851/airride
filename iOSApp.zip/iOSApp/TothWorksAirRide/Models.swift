import Foundation
import UIKit

enum BleConnectionState: String {
    case disconnected
    case scanning
    case connecting
    case connected
    case authenticating
    case authenticated
    case error
}

struct ScannedDevice: Identifiable, Equatable {
    let id: String          // Peripheral UUID string
    let name: String
    let rssi: Int
}

struct SavedDevice: Codable, Identifiable, Equatable {
    var id: String          // Peripheral UUID string
    var name: String
    var savedPin: String?
    var carName: String
    var backgroundFilename: String?
    var extra1Name: String
    var extra2Name: String

    static func createDefault(id: String, name: String, savedPin: String?) -> SavedDevice {
        return SavedDevice(
            id: id,
            name: name,
            savedPin: savedPin,
            carName: "AIR RIDE",
            backgroundFilename: nil,
            extra1Name: "Extra 1",
            extra2Name: "Extra 2"
        )
    }
}

struct CarState: Equatable {
    var frontHeight: Float = 0.5
    var rearHeight: Float = 0.5
}

final class DeviceStore: ObservableObject {
    @Published private(set) var savedDevices: [SavedDevice] = []
    private let storageKey = "tothworks_airride_saved_devices_v1"

    init() {
        load()
    }

    func load() {
        guard let data = UserDefaults.standard.data(forKey: storageKey),
              let decoded = try? JSONDecoder().decode([SavedDevice].self, from: data) else {
            savedDevices = []
            return
        }
        savedDevices = decoded
    }

    private func persist() {
        if let data = try? JSONEncoder().encode(savedDevices) {
            UserDefaults.standard.set(data, forKey: storageKey)
        }
    }

    func upsert(_ device: SavedDevice) {
        if let idx = savedDevices.firstIndex(where: { $0.id == device.id }) {
            savedDevices[idx] = device
        } else {
            savedDevices.append(device)
        }
        persist()
    }

    func delete(_ device: SavedDevice) {
        if let bg = device.backgroundFilename {
            deleteBackgroundImage(filename: bg)
        }
        savedDevices.removeAll { $0.id == device.id }
        persist()
    }

    func updatePin(deviceId: String, pin: String?) {
        guard let idx = savedDevices.firstIndex(where: { $0.id == deviceId }) else { return }
        savedDevices[idx].savedPin = pin
        persist()
    }

    func updateCarInfo(deviceId: String, carName: String, backgroundFilename: String?) {
        guard let idx = savedDevices.firstIndex(where: { $0.id == deviceId }) else { return }
        savedDevices[idx].carName = carName
        savedDevices[idx].backgroundFilename = backgroundFilename
        persist()
    }

    func updateExtraNames(deviceId: String, name1: String, name2: String) {
        guard let idx = savedDevices.firstIndex(where: { $0.id == deviceId }) else { return }
        savedDevices[idx].extra1Name = name1
        savedDevices[idx].extra2Name = name2
        persist()
    }

    // ── Háttérkép mentés / betöltés a Documents mappába ──
    private var documentsDir: URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
    }

    func saveBackgroundImage(_ image: UIImage, for deviceId: String) -> String? {
        guard let data = image.jpegData(compressionQuality: 0.85) else { return nil }
        let safeId = deviceId.replacingOccurrences(of: "[^A-Za-z0-9_-]", with: "_", options: .regularExpression)
        let filename = "bg_\(safeId)_\(Int(Date().timeIntervalSince1970)).jpg"
        let url = documentsDir.appendingPathComponent(filename)
        do {
            try data.write(to: url, options: .atomic)
            return filename
        } catch {
            return nil
        }
    }

    func loadBackgroundImage(filename: String?) -> UIImage? {
        guard let filename = filename, !filename.isEmpty else { return nil }
        let url = documentsDir.appendingPathComponent(filename)
        guard let data = try? Data(contentsOf: url) else { return nil }
        return UIImage(data: data)
    }

    func deleteBackgroundImage(filename: String) {
        let url = documentsDir.appendingPathComponent(filename)
        try? FileManager.default.removeItem(at: url)
    }
}
