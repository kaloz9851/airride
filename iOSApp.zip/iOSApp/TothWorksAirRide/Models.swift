import Foundation
import UIKit

enum BleConnectionState: String {
    case disconnected
    case scanning
    case connecting
    case connected
    case authenticating
    case authenticated
    case error
}

struct ScannedDevice: Identifiable, Equatable {
    let id: String          // Peripheral UUID string
    let name: String
    let rssi: Int
}

struct SensorCal: Equatable {
    var zeroV: Float = 0.500
    var psiPerV: Float = 37.50
}

struct HoldState: Equatable {
    var active: Bool = false
    var frontPsi: Float = 0
    var rearPsi: Float = 0
    var error: Bool = false
}

struct PressurePreset: Codable, Equatable, Identifiable {
    var id: Int
    var name: String
    var frontPsi: Float
    var rearPsi: Float

    static let maxPsi: Float = 200.0

    static func defaults() -> [PressurePreset] {
        return [
            PressurePreset(id: 0, name: "1. ÉRTÉK", frontPsi: 65, rearPsi: 52),
            PressurePreset(id: 1, name: "2. ÉRTÉK", frontPsi: 80, rearPsi: 70),
            PressurePreset(id: 2, name: "3. ÉRTÉK", frontPsi: 45, rearPsi: 40),
            PressurePreset(id: 3, name: "4. ÉRTÉK", frontPsi: 30, rearPsi: 25)
        ]
    }
}

struct SavedDevice: Codable, Identifiable, Equatable {
    var id: String          // Peripheral UUID string
    var name: String
    var savedPin: String?
    var carName: String
    var backgroundFilename: String?
    var presets: [PressurePreset]

    static func createDefault(id: String, name: String, savedPin: String?) -> SavedDevice {
        return SavedDevice(
            id: id,
            name: name,
            savedPin: savedPin,
            carName: "AIR RIDE",
            backgroundFilename: nil,
            presets: PressurePreset.defaults()
        )
    }
}

struct CarState: Equatable {
    var frontHeight: Float = 0.5
    var rearHeight: Float = 0.5
}

final class DeviceStore: ObservableObject {
    @Published private(set) var savedDevices: [SavedDevice] = []
    private let storageKey = "tothworks_airride_sensor_saved_devices_v1"

    init() {
        load()
    }

    func load() {
        guard let data = UserDefaults.standard.data(forKey: storageKey),
              let decoded = try? JSONDecoder().decode([SavedDevice].self, from: data) else {
            savedDevices = []
            return
        }
        savedDevices = decoded
    }

    private func persist() {
        if let data = try? JSONEncoder().encode(savedDevices) {
            UserDefaults.standard.set(data, forKey: storageKey)
        }
    }

    func upsert(_ device: SavedDevice) {
        if let idx = savedDevices.firstIndex(where: { $0.id == device.id }) {
            savedDevices[idx] = device
        } else {
            savedDevices.append(device)
        }
        persist()
    }

    func delete(_ device: SavedDevice) {
        if let bg = device.backgroundFilename {
            deleteBackgroundImage(filename: bg)
        }
        savedDevices.removeAll { $0.id == device.id }
        persist()
    }

    func updatePin(deviceId: String, pin: String?) {
        guard let idx = savedDevices.firstIndex(where: { $0.id == deviceId }) else { return }
        savedDevices[idx].savedPin = pin
        persist()
    }

    func updateCarInfo(deviceId: String, carName: String, backgroundFilename: String?) {
        guard let idx = savedDevices.firstIndex(where: { $0.id == deviceId }) else { return }
        savedDevices[idx].carName = carName
        savedDevices[idx].backgroundFilename = backgroundFilename
        persist()
    }

    func updatePresets(deviceId: String, presets: [PressurePreset]) {
        guard let idx = savedDevices.firstIndex(where: { $0.id == deviceId }) else { return }
        savedDevices[idx].presets = presets
        persist()
    }

    // ── Háttérkép mentés / betöltés a Documents mappába ──
    private var documentsDir: URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
    }

    func saveBackgroundImage(_ image: UIImage, for deviceId: String) -> String? {
        guard let data = image.jpegData(compressionQuality: 0.85) else { return nil }
        let safeId = deviceId.replacingOccurrences(of: "[^A-Za-z0-9_-]", with: "_", options: .regularExpression)
        let filename = "bg_\(safeId)_\(Int(Date().timeIntervalSince1970)).jpg"
        let url = documentsDir.appendingPathComponent(filename)
        do {
            try data.write(to: url, options: .atomic)
            return filename
        } catch {
            return nil
        }
    }

    func loadBackgroundImage(filename: String?) -> UIImage? {
        guard let filename = filename, !filename.isEmpty else { return nil }
        let url = documentsDir.appendingPathComponent(filename)
        guard let data = try? Data(contentsOf: url) else { return nil }
        return UIImage(data: data)
    }

    func deleteBackgroundImage(filename: String) {
        let url = documentsDir.appendingPathComponent(filename)
        try? FileManager.default.removeItem(at: url)
    }
}
