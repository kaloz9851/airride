import Foundation
import Combine
import UIKit

final class MainViewModel: ObservableObject {

    let bleManager = BleManager()
    let deviceStore = DeviceStore()

    @Published var connectionState: BleConnectionState = .disconnected
    @Published var statusMessage: String = ""
    @Published var relayStates: [Bool] = [false, false, false, false]
    @Published var pressures: [Float] = [0.0, 0.0, 0.0]
    @Published var voltages: [Float] = [0.0, 0.0, 0.0]
    @Published var adsOk: Bool = true
    @Published var calibrations: [SensorCal] = [
        SensorCal(zeroV: 0.500, psiPerV: 37.50),
        SensorCal(zeroV: 0.500, psiPerV: 37.50),
        SensorCal(zeroV: 0.500, psiPerV: 37.50)
    ]
    @Published var holdState: HoldState = HoldState()
    @Published var calSavedCounter: Int = 0
    @Published var scannedDevices: [ScannedDevice] = []
    @Published var savedDevices: [SavedDevice] = []

    @Published var activeDevice: SavedDevice? = nil
    @Published var carState: CarState = CarState()
    @Published var showPinDialog: Bool = false
    @Published var showChangePinAfterMaster: Bool = false

    private var cancellables = Set<AnyCancellable>()
    private var animTimer: Timer?
    private var pendingConnectScanned: ScannedDevice?
    private var pendingSavePin: Bool = false
    private var pendingPinValue: String?

    var presets: [PressurePreset] {
        activeDevice?.presets ?? PressurePreset.defaults()
    }

    var activePresetIndex: Int? {
        guard holdState.active else { return nil }
        return presets.firstIndex { p in
            abs(p.frontPsi - holdState.frontPsi) < 0.06 &&
            abs(p.rearPsi - holdState.rearPsi) < 0.06
        }
    }

    init() {
        setupBindings()
        startCarPhysicsTimer()

        // Automatikus csatlakozás mentett eszközökhöz
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) { [weak self] in
            guard let self = self else { return }
            if !self.deviceStore.savedDevices.isEmpty {
                var map: [String: String?] = [:]
                for d in self.deviceStore.savedDevices {
                    map[d.id] = d.savedPin
                }
                self.bleManager.startAutoScan(devices: map)
            }
        }
    }

    deinit {
        animTimer?.invalidate()
    }

    private func setupBindings() {
        deviceStore.$savedDevices
            .receive(on: DispatchQueue.main)
            .sink { [weak self] list in
                guard let self = self else { return }
                self.savedDevices = list
                if let curId = self.activeDevice?.id {
                    self.activeDevice = list.first(where: { $0.id == curId })
                } else if self.activeDevice == nil {
                    self.activeDevice = list.first
                }
            }
            .store(in: &cancellables)

        bleManager.$connectionState
            .receive(on: DispatchQueue.main)
            .sink { [weak self] state in
                guard let self = self else { return }
                self.connectionState = state

                if state == .authenticating {
                    let hasPin = (self.activeDevice?.savedPin != nil) || (self.pendingPinValue != nil)
                    if !hasPin {
                        self.showPinDialog = true
                    }
                } else if state == .authenticated {
                    self.showPinDialog = false
                    if let scanned = self.pendingConnectScanned {
                        let pinToSave = self.pendingSavePin ? self.pendingPinValue : nil
                        let existing = self.deviceStore.savedDevices.first(where: { $0.id == scanned.id })
                        let dev = existing ?? SavedDevice.createDefault(id: scanned.id, name: scanned.name, savedPin: pinToSave)
                        self.deviceStore.upsert(dev)
                        if self.pendingSavePin, let p = self.pendingPinValue {
                            self.deviceStore.updatePin(deviceId: scanned.id, pin: p)
                        }
                        self.activeDevice = self.deviceStore.savedDevices.first(where: { $0.id == scanned.id })
                        self.pendingConnectScanned = nil
                    } else if let act = self.activeDevice, self.pendingSavePin, let p = self.pendingPinValue {
                        self.deviceStore.updatePin(deviceId: act.id, pin: p)
                    }
                } else if state == .disconnected || state == .error {
                    self.showPinDialog = false
                }
            }
            .store(in: &cancellables)

        bleManager.$connectedDeviceId
            .receive(on: DispatchQueue.main)
            .sink { [weak self] id in
                guard let self = self, let id = id else { return }
                if let match = self.deviceStore.savedDevices.first(where: { $0.id == id }) {
                    self.activeDevice = match
                }
            }
            .store(in: &cancellables)

        bleManager.$statusMessage
            .receive(on: DispatchQueue.main)
            .sink { [weak self] msg in
                guard let self = self else { return }
                self.statusMessage = msg
                if msg == "MASTER_AUTH_OK" {
                    self.showPinDialog = false
                    self.showChangePinAfterMaster = true
                } else if msg == "AUTH_FAIL" {
                    self.pendingPinValue = nil
                    if let act = self.activeDevice {
                        self.deviceStore.updatePin(deviceId: act.id, pin: nil)
                    }
                    self.showPinDialog = true
                }
            }
            .store(in: &cancellables)

        bleManager.$relayStates.receive(on: DispatchQueue.main).assign(to: &$relayStates)
        bleManager.$pressures.receive(on: DispatchQueue.main).assign(to: &$pressures)
        bleManager.$voltages.receive(on: DispatchQueue.main).assign(to: &$voltages)
        bleManager.$adsOk.receive(on: DispatchQueue.main).assign(to: &$adsOk)
        bleManager.$calibrations.receive(on: DispatchQueue.main).assign(to: &$calibrations)
        bleManager.$holdState.receive(on: DispatchQueue.main).assign(to: &$holdState)
        bleManager.$calSavedCounter.receive(on: DispatchQueue.main).assign(to: &$calSavedCounter)
        bleManager.$scannedDevices.receive(on: DispatchQueue.main).assign(to: &$scannedDevices)
    }

    private func startCarPhysicsTimer() {
        animTimer = Timer.scheduledTimer(withTimeInterval: 0.035, repeats: true) { [weak self] _ in
            guard let self = self else { return }
            let r = self.relayStates
            guard r.count >= 4 else { return }
            var fh = self.carState.frontHeight
            var rh = self.carState.rearHeight
            let step: Float = 0.018

            if r[0] { fh = min(1.0, fh + step) }
            if r[1] { fh = max(0.0, fh - step) }
            if r[2] { rh = min(1.0, rh + step) }
            if r[3] { rh = max(0.0, rh - step) }

            if fh != self.carState.frontHeight || rh != self.carState.rearHeight {
                self.carState = CarState(frontHeight: fh, rearHeight: rh)
            }
        }
    }

    // MARK: - Vezérlő műveletek

    func relayOn(_ index: Int) {
        bleManager.setRelay(index: index, on: true)
    }

    func relayOff(_ index: Int) {
        bleManager.setRelay(index: index, on: false)
    }

    func relayComboOn(_ combo: String) {
        bleManager.setRelayCombo(combo, on: true)
    }

    func relayComboOff(_ combo: String) {
        bleManager.setRelayCombo(combo, on: false)
    }

    // MARK: - Eszköz és PIN műveletek

    func startScan() {
        bleManager.startScan()
    }

    func connectToDevice(_ device: SavedDevice) {
        activeDevice = device
        pendingConnectScanned = nil
        pendingPinValue = device.savedPin
        pendingSavePin = false
        bleManager.connect(deviceId: device.id, pin: device.savedPin)
    }

    func connectToScanned(_ scanned: ScannedDevice, pin: String, savePin: Bool) {
        pendingConnectScanned = scanned
        pendingPinValue = pin
        pendingSavePin = savePin
        let dev = SavedDevice.createDefault(id: scanned.id, name: scanned.name, savedPin: savePin ? pin : nil)
        deviceStore.upsert(dev)
        activeDevice = deviceStore.savedDevices.first(where: { $0.id == scanned.id })
        bleManager.connect(deviceId: scanned.id, pin: pin)
    }

    func disconnect() {
        bleManager.disconnect()
    }

    func deleteDevice(_ device: SavedDevice) {
        if activeDevice?.id == device.id {
            disconnect()
            activeDevice = nil
        }
        deviceStore.delete(device)
    }

    func authenticate(pin: String, save: Bool) {
        pendingPinValue = pin
        pendingSavePin = save
        bleManager.authenticate(pin: pin)
    }

    func authenticateMaster(_ masterPassword: String) {
        bleManager.sendMasterAuth(masterPassword: masterPassword)
    }

    func changePin(_ newPin: String) {
        bleManager.changePin(newPin)
        if let act = activeDevice, act.savedPin != nil {
            deviceStore.updatePin(deviceId: act.id, pin: newPin)
        }
        showChangePinAfterMaster = false
    }

    func updateCarInfo(deviceId: String, carName: String, backgroundFilename: String?) {
        deviceStore.updateCarInfo(deviceId: deviceId, carName: carName, backgroundFilename: backgroundFilename)
    }

    func setCustomBackgroundImage(_ image: UIImage) {
        guard let dev = activeDevice else { return }
        if let old = dev.backgroundFilename {
            deviceStore.deleteBackgroundImage(filename: old)
        }
        if let filename = deviceStore.saveBackgroundImage(image, for: dev.id) {
            deviceStore.updateCarInfo(deviceId: dev.id, carName: dev.carName, backgroundFilename: filename)
        }
    }

    func removeCustomBackgroundImage() {
        guard let dev = activeDevice else { return }
        if let old = dev.backgroundFilename {
            deviceStore.deleteBackgroundImage(filename: old)
        }
        deviceStore.updateCarInfo(deviceId: dev.id, carName: dev.carName, backgroundFilename: nil)
    }

    // MARK: - Auto nyomástartás & Kalibráció

    func savePreset(index: Int, preset: PressurePreset) {
        guard let dev = activeDevice, (0..<4).contains(index) else { return }
        let wasActive = (activePresetIndex == index)
        var list = dev.presets
        var updated = preset
        updated.id = index
        list[index] = updated
        deviceStore.updatePresets(deviceId: dev.id, presets: list)
        if wasActive {
            bleManager.holdOn(frontPsi: updated.frontPsi, rearPsi: updated.rearPsi)
        }
    }

    func activatePreset(_ index: Int) {
        let list = presets
        guard (0..<list.count).contains(index) else { return }
        let p = list[index]
        bleManager.holdOn(frontPsi: p.frontPsi, rearPsi: p.rearPsi)
    }

    func deactivateHold() {
        bleManager.holdOff()
    }

    func calibrateZero(_ sensor: Int) {
        bleManager.calibrateZero(sensor: sensor)
    }

    func calibrateSpan(_ sensor: Int, referencePsi: Float) {
        bleManager.calibrateSpan(sensor: sensor, referencePsi: referencePsi)
    }

    func calibrateReset(_ sensor: Int) {
        bleManager.calibrateReset(sensor: sensor)
    }

    func saveCalibration() {
        bleManager.saveCalibration()
    }

    func requestCalibration() {
        bleManager.requestCalibration()
    }
}
