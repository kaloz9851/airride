import SwiftUI

struct MainScreen: View {
    @ObservedObject var viewModel: MainViewModel
    let onNavigateToMenu: () -> Void
    let onNavigateToExtras: () -> Void

    @State private var editingCarName = false
    @State private var carNameInput = "AIR RIDE"
    @State private var namePulse = false

    private var isAuthenticated: Bool {
        viewModel.connectionState == .authenticated
    }

    private var customBgImage: UIImage? {
        viewModel.deviceStore.loadBackgroundImage(filename: viewModel.activeDevice?.backgroundFilename)
    }

    var body: some View {
        ZStack {
            // 1. Háttér: Carbon fiber vagy egyéni háttérkép
            if let bg = customBgImage {
                GeometryReader { geo in
                    Image(uiImage: bg)
                        .resizable()
                        .scaledToFill()
                        .frame(width: geo.size.width, height: geo.size.height)
                        .clipped()
                }
                .ignoresSafeArea()
            } else {
                CarbonFiberBackground()
            }

            // 2. Sötétítő átmenet (Gradient overlay)
            LinearGradient(
                colors: [
                    AppTheme.deepBlack.opacity(customBgImage != nil ? 0.55 : 0.90),
                    AppTheme.deepBlack.opacity(customBgImage != nil ? 0.30 : 0.70),
                    AppTheme.deepBlack.opacity(customBgImage != nil ? 0.65 : 0.95)
                ],
                startPoint: .top,
                endPoint: .bottom
            )
            .ignoresSafeArea()

            // 3. Fő tartalom (iPhone és iPad méretezéssel)
            VStack(spacing: 0) {
                topBar

                Spacer(minLength: 8)

                VStack(spacing: 8) {
                    animatedStatusStrip
                    CarView(
                        frontHeight: viewModel.carState.frontHeight,
                        rearHeight: viewModel.carState.rearHeight
                    )
                    .frame(height: 170)
                    .padding(.horizontal, 8)
                    GroundLine()
                }
                .padding(.horizontal, 16)

                Spacer(minLength: 10)

                controlPanel
                    .padding(.horizontal, 20)

                Spacer(minLength: 8)

                carNameBar
                infoBar
            }
            .frame(maxWidth: 560)
        }
        .onAppear {
            carNameInput = viewModel.activeDevice?.carName ?? "AIR RIDE"
            withAnimation(.easeInOut(duration: 1.8).repeatForever(autoreverses: true)) {
                namePulse = true
            }
        }
        .onChange(of: viewModel.activeDevice) { dev in
            if let name = dev?.carName {
                carNameInput = name
            }
        }
        .sheet(isPresented: $viewModel.showPinDialog) {
            PinSheetView(viewModel: viewModel)
        }
        .sheet(isPresented: $viewModel.showChangePinAfterMaster) {
            ChangePinAfterMasterSheet(viewModel: viewModel)
        }
    }

    // MARK: - TopBar

    private var topBar: some View {
        HStack(spacing: 8) {
            if UIImage(named: "tothworks_logo") != nil {
                Image("tothworks_logo")
                    .resizable()
                    .scaledToFit()
                    .frame(height: 36)
            } else {
                Text("TOTH\nWORKS")
                    .font(.system(size: 11, weight: .black))
                    .tracking(2)
                    .foregroundColor(AppTheme.neonBlue)
            }

            Spacer()

            ConnectionStatusBadge(
                state: viewModel.connectionState,
                deviceName: viewModel.activeDevice?.name ?? ""
            )

            // EXTRA gomb (R5 / R6 kapcsolókhoz navigál)
            Button(action: onNavigateToExtras) {
                Text("EXTRA")
                    .font(.system(size: 11, weight: .black))
                    .tracking(1)
                    .foregroundColor(AppTheme.neonCyan)
                    .padding(.horizontal, 10)
                    .padding(.vertical, 6)
                    .background(AppTheme.darkSurface)
                    .overlay(
                        RoundedRectangle(cornerRadius: 8)
                            .stroke(AppTheme.neonCyan.opacity(0.65), lineWidth: 1)
                    )
                    .cornerRadius(8)
            }

            Button(action: onNavigateToMenu) {
                Image(systemName: "line.3.horizontal")
                    .font(.system(size: 22, weight: .bold))
                    .foregroundColor(AppTheme.neonBlue)
                    .frame(width: 36, height: 36)
            }
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 10)
    }

    // MARK: - AnimatedStatusStrip (R1..R4 relé állapotok)

    private var animatedStatusStrip: some View {
        let labels = ["R1\nELÖL FEL.", "R2\nELÖL LE.", "R3\nHÁTUL FEL.", "R4\nHÁTUL LE."]
        return HStack {
            ForEach(0..<4, id: \.self) { i in
                RelayIndicatorView(
                    label: labels[i],
                    active: viewModel.relayStates[safe: i] ?? false,
                    enabled: isAuthenticated
                )
                if i < 3 { Spacer() }
            }
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 8)
        .background(AppTheme.cardBackground.opacity(0.82))
        .overlay(
            RoundedRectangle(cornerRadius: 8)
                .stroke(AppTheme.cardBorder, lineWidth: 1)
        )
        .cornerRadius(8)
    }

    // MARK: - ControlPanel (4 nyíl + 2 kombó gomb)

    private var controlPanel: some View {
        VStack(spacing: 16) {
            HStack(alignment: .center) {
                Spacer()
                // ELSŐ TENGELY
                VStack(spacing: 8) {
                    Text("ELSŐ\nTENGELY")
                        .font(.system(size: 10, weight: .bold))
                        .tracking(1)
                        .multilineTextAlignment(.center)
                        .foregroundColor(AppTheme.neonBlue.opacity(0.75))

                    ArrowButton(
                        direction: .up,
                        size: 90,
                        color: isAuthenticated ? AppTheme.neonBlue : AppTheme.textDisabled,
                        isEnabled: isAuthenticated,
                        onPress: { viewModel.relayOn(0) },
                        onRelease: { viewModel.relayOff(0) }
                    )

                    ArrowButton(
                        direction: .down,
                        size: 90,
                        color: isAuthenticated ? AppTheme.neonBlue.opacity(0.85) : AppTheme.textDisabled,
                        isEnabled: isAuthenticated,
                        onPress: { viewModel.relayOn(1) },
                        onRelease: { viewModel.relayOff(1) }
                    )
                }
                .frame(width: 120)

                Spacer()

                Rectangle()
                    .fill(
                        LinearGradient(
                            colors: [.clear, AppTheme.cardBorder, .clear],
                            startPoint: .top,
                            endPoint: .bottom
                        )
                    )
                    .frame(width: 1, height: 120)

                Spacer()

                // HÁTSÓ TENGELY
                VStack(spacing: 8) {
                    Text("HÁTSÓ\nTENGELY")
                        .font(.system(size: 10, weight: .bold))
                        .tracking(1)
                        .multilineTextAlignment(.center)
                        .foregroundColor(AppTheme.neonCyan.opacity(0.75))

                    ArrowButton(
                        direction: .up,
                        size: 90,
                        color: isAuthenticated ? AppTheme.neonCyan : AppTheme.textDisabled,
                        isEnabled: isAuthenticated,
                        onPress: { viewModel.relayOn(2) },
                        onRelease: { viewModel.relayOff(2) }
                    )

                    ArrowButton(
                        direction: .down,
                        size: 90,
                        color: isAuthenticated ? AppTheme.neonCyan.opacity(0.85) : AppTheme.textDisabled,
                        isEnabled: isAuthenticated,
                        onPress: { viewModel.relayOn(3) },
                        onRelease: { viewModel.relayOff(3) }
                    )
                }
                .frame(width: 120)
                Spacer()
            }

            HStack(spacing: 12) {
                ComboActionButton(
                    label: "▲  MIND FEL  ▲",
                    color: AppTheme.neonBlue,
                    isEnabled: isAuthenticated,
                    onPress: { viewModel.relayComboOn("13") },
                    onRelease: { viewModel.relayComboOff("13") }
                )

                ComboActionButton(
                    label: "▼  MIND LE  ▼",
                    color: AppTheme.neonCyan,
                    isEnabled: isAuthenticated,
                    onPress: { viewModel.relayComboOn("24") },
                    onRelease: { viewModel.relayComboOff("24") }
                )
            }
        }
        .opacity(isAuthenticated ? 1.0 : 0.42)
    }

    // MARK: - CarNameBar & InfoBar

    private var carNameBar: some View {
        HStack {
            if editingCarName {
                HStack {
                    TextField("Autónév / Rendszám", text: $carNameInput)
                        .font(.system(size: 16, weight: .bold))
                        .foregroundColor(AppTheme.textPrimary)
                        .multilineTextAlignment(.center)
                        .padding(8)
                        .background(AppTheme.darkSurface)
                        .cornerRadius(8)
                        .overlay(RoundedRectangle(cornerRadius: 8).stroke(AppTheme.neonBlue, lineWidth: 1))

                    Button(action: {
                        editingCarName = false
                        if let dev = viewModel.activeDevice {
                            viewModel.updateCarInfo(
                                deviceId: dev.id,
                                carName: carNameInput,
                                backgroundFilename: dev.backgroundFilename
                            )
                        }
                    }) {
                        Image(systemName: "checkmark.circle.fill")
                            .font(.system(size: 24))
                            .foregroundColor(AppTheme.neonGreen)
                    }
                }
                .padding(.horizontal, 24)
            } else {
                Button(action: { editingCarName = true }) {
                    HStack(spacing: 8) {
                        Text(carNameInput.uppercased())
                            .font(.system(size: 22, weight: .black))
                            .tracking(6)
                            .foregroundColor(AppTheme.neonBlue.opacity(namePulse ? 1.0 : 0.55))
                        Image(systemName: "pencil")
                            .font(.system(size: 14))
                            .foregroundColor(AppTheme.textDisabled)
                    }
                }
            }
        }
        .padding(.vertical, 6)
    }

    private var infoBar: some View {
        Text("TothWorks Air Ride  •  Lizi Design copyright •  v2.3")
            .font(.system(size: 9))
            .tracking(0.5)
            .foregroundColor(AppTheme.textDisabled)
            .padding(.bottom, 8)
    }
}

struct RelayIndicatorView: View {
    let label: String
    let active: Bool
    let enabled: Bool

    var body: some View {
        let color: Color = {
            if !enabled { return AppTheme.textDisabled }
            return active ? AppTheme.neonGreen : AppTheme.textSecondary
        }()

        VStack(spacing: 4) {
            Circle()
                .fill(color)
                .frame(width: 10, height: 10)
                .shadow(color: (active && enabled) ? AppTheme.neonGreen : .clear, radius: 6)
            Text(label)
                .font(.system(size: 8, weight: .bold))
                .foregroundColor(color)
                .multilineTextAlignment(.center)
                .lineSpacing(1)
        }
        .scaleEffect((active && enabled) ? 1.12 : 1.0)
        .animation(.spring(response: 0.25, dampingFraction: 0.55), value: active)
    }
}

// MARK: - PIN Dialógusok

struct PinSheetView: View {
    @ObservedObject var viewModel: MainViewModel
    @State private var pinInput = ""
    @State private var masterInput = ""
    @State private var showMaster = false
    @State private var savePin = true

    var body: some View {
        ZStack {
            AppTheme.deepBlack.ignoresSafeArea()
            VStack(spacing: 16) {
                Text(showMaster ? "MESTERJELSZÓ" : "PIN KÓD")
                    .font(.system(size: 18, weight: .black))
                    .tracking(2)
                    .foregroundColor(AppTheme.neonBlue)

                if !showMaster {
                    SecureField("4 jegyű PIN", text: $pinInput)
                        .keyboardType(.numberPad)
                        .padding(12)
                        .background(AppTheme.cardBackground)
                        .foregroundColor(AppTheme.textPrimary)
                        .cornerRadius(8)
                        .overlay(RoundedRectangle(cornerRadius: 8).stroke(AppTheme.neonBlue, lineWidth: 1))
                        .onChange(of: pinInput) { val in
                            pinInput = String(val.filter { $0.isNumber }.prefix(4))
                        }

                    Toggle(isOn: $savePin) {
                        Text("Jelszó mentése (automatikus belépés)")
                            .font(.system(size: 13))
                            .foregroundColor(AppTheme.textSecondary)
                    }
                    .tint(AppTheme.neonBlue)

                    Button(action: { showMaster = true }) {
                        Text("Elfelejtett PIN? Mesterjelszó használata")
                            .font(.system(size: 12, weight: .semibold))
                            .foregroundColor(AppTheme.authOrange)
                    }
                } else {
                    SecureField("Mesterjelszó", text: $masterInput)
                        .padding(12)
                        .background(AppTheme.cardBackground)
                        .foregroundColor(AppTheme.textPrimary)
                        .cornerRadius(8)
                        .overlay(RoundedRectangle(cornerRadius: 8).stroke(AppTheme.authOrange, lineWidth: 1))

                    Button(action: { showMaster = false }) {
                        Text("Vissza a PIN kódhoz")
                            .font(.system(size: 12, weight: .semibold))
                            .foregroundColor(AppTheme.neonBlue)
                    }
                }

                HStack(spacing: 12) {
                    Button(action: { viewModel.showPinDialog = false }) {
                        Text("MÉGSE")
                            .font(.system(size: 13, weight: .bold))
                            .foregroundColor(AppTheme.textSecondary)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 12)
                            .background(AppTheme.cardBackground)
                            .cornerRadius(8)
                    }

                    Button(action: {
                        if showMaster {
                            viewModel.authenticateMaster(masterInput)
                        } else if pinInput.count == 4 {
                            viewModel.authenticate(pin: pinInput, save: savePin)
                        }
                    }) {
                        Text("BELÉPÉS")
                            .font(.system(size: 13, weight: .bold))
                            .foregroundColor(AppTheme.deepBlack)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 12)
                            .background(AppTheme.neonBlue)
                            .cornerRadius(8)
                    }
                }
            }
            .padding(24)
        }
        .presentationDetents([.height(310)])
    }
}

struct ChangePinAfterMasterSheet: View {
    @ObservedObject var viewModel: MainViewModel
    @State private var newPin = ""

    var body: some View {
        ZStack {
            AppTheme.deepBlack.ignoresSafeArea()
            VStack(spacing: 16) {
                Text("ÚJ PIN BEÁLLÍTÁSA")
                    .font(.system(size: 18, weight: .black))
                    .tracking(2)
                    .foregroundColor(AppTheme.neonGreen)

                SecureField("Új 4 jegyű PIN", text: $newPin)
                    .keyboardType(.numberPad)
                    .padding(12)
                    .background(AppTheme.cardBackground)
                    .foregroundColor(AppTheme.textPrimary)
                    .cornerRadius(8)
                    .overlay(RoundedRectangle(cornerRadius: 8).stroke(AppTheme.neonGreen, lineWidth: 1))
                    .onChange(of: newPin) { val in
                        newPin = String(val.filter { $0.isNumber }.prefix(4))
                    }

                Button(action: {
                    if newPin.count == 4 {
                        viewModel.changePin(newPin)
                    }
                }) {
                    Text("MENTÉS")
                        .font(.system(size: 13, weight: .bold))
                        .foregroundColor(AppTheme.deepBlack)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 12)
                        .background(newPin.count == 4 ? AppTheme.neonGreen : AppTheme.textDisabled)
                        .cornerRadius(8)
                }
            }
            .padding(24)
        }
        .presentationDetents([.height(240)])
    }
}

extension Collection {
    subscript(safe index: Index) -> Element? {
        return indices.contains(index) ? self[index] : nil
    }
}
