# TothWorks Air Ride Sensor – iOS és iPadOS Telepítési Útmutató (`.ipa`)

Ez a mappa (`iOSApp`) tartalmazza a **TothWorks Air Ride Sensor** natív **iPhone és iPad (SwiftUI + CoreBluetooth BLE)** alkalmazásának teljes forráskódját, ikonjait és grafikai elemeit (`bck_logo.png`, `car_logo.png`, `tothworks_logo.png`, `conn_logo.png`), valamint az automatikus `.ipa` telepítőcsomag-készítőt.

---

## Miért szükséges felhős (vagy Mac-es) fordítás az `.ipa` fájlhoz?
Az Apple kizárólag a saját **macOS + Xcode** rendszerén engedi lefordítani az iOS alkalmazásokat (Windows-ra nem létezik hivatalos Apple Swift/iOS fordító). Emiatt készítettem el a projektbe az **automatikus GitHub Actions felhős Mac fordítót** (`.github/workflows/build-ios-ipa.yml`), amely ingyenesen, egyetlen kattintással legyártja neked a kész **`TothWorks Air Ride Sensor.ipa`** fájlt!

---

## 1. LÉPÉS: A `TothWorks Air Ride Sensor.ipa` fájl legenerálása (Mac nélkül, Windows-ról)

1. Hozz létre egy ingyenes privát (vagy publikus) tárolót (repository-t) a [github.com](https://github.com) oldalon.
2. Töltsd fel bele a `TothWorksAirRideSensor` mappa tartalmát (benne az `iOSApp` és a `.github/workflows/build-ios-ipa.yml` mappákkal).
3. A GitHub oldalon kattints felül az **Actions** fülre:
   - Automatikusan elindul a **Build iOS & iPadOS IPA (TothWorks Air Ride Sensor)** folyamat (vagy a *Run workflow* gombbal bármikor elindíthatod).
   - ~2-3 perc múlva, amikor zöld pipát kap, kattints rá a lefutott munkafolyamatra, és alul az **Artifacts** résznél töltsd le a **`TothWorks-Air-Ride-Sensor-iOS-IPA`** csomagot.
   - Ebben található a kész **`TothWorks Air Ride Sensor.ipa`** telepítőfájl!

*(Ha van kéznél Mac számítógép, ott még egyszerűbb: nyisd meg a terminált az `iOSApp` mappában, és futtasd a `./build_ipa_mac.sh` parancsot, vagy nyisd meg Xcode-ban!)*

---

## 2. LÉPÉS: A `.ipa` telepítése iPhone-ra és iPadre (Windows PC-ről)

Az Apple rendszerén az `.ipa` fájlok telepítésére két módszer létezik:

### A) Ingyenes telepítés Windows PC-ről – **Sideloadly** programmal (Apple előfizetés nélkül)
1. Töltsd le és telepítsd a Windows gépedre az ingyenes **Sideloadly** programot ([sideloadly.io](https://sideloadly.io/)) valamint az Apple **iTunes** és **iCloud** (nem Microsoft Store-os, hanem közvetlen Apple weboldalas) verzióját.
2. Csatlakoztasd az **iPhone** vagy **iPad** készüléket USB kábellel a PC-hez, és a telefonon/tableten nyomj a **„Megbízhatónak nyilvánítás” (Trust)** gombra.
3. Nyisd meg a **Sideloadly**-t:
   - Húzd bele a **`TothWorks Air Ride Sensor.ipa`** fájlt az *IPA* mezőbe.
   - Az *Apple ID* mezőbe írd be a saját Apple ID e-mail címedet (a Sideloadly ezzel írja alá digitálisan a készülékedre az appot).
   - Kattints a **Start** gombra!
4. Amikor feltelepült, az iPhone / iPad készüléken lépj ide:
   - **Beállítások -> Általános -> VPN és eszközfelügyelet** (Settings -> General -> VPN & Device Management) -> válaszd ki a saját Apple ID-dat -> nyomj a **Megbízhatónak nyilvánítás (Trust)** gombra.
   - Kapcsold be a **Fejlesztői módot (Developer Mode)** is (*Beállítások -> Adatvédelem és biztonság -> Fejlesztői mód*).
5. Most már a főképernyőről indítható a **TothWorks Air Ride** alkalmazás, és közvetlenül **Bluetooth BLE**-n keresztül vezérli az ESP32-C3 modult!

### B) Hivatalos korlátlan terjesztés ügyfeleknek – **Apple Developer Program** (TestFlight / Ad-Hoc / App Store)
- Ha üzleti ügyfeleknek is szeretnéd küldeni az iOS appot úgy, hogy egyetlen linkre kattintva (PC nélkül) feltelepüljön az iPhone-jukra vagy iPadjükre és soha ne járjon le:
  - Regisztrálj egy **Apple Developer** fiókot (99 USD / év).
  - A **TestFlight** rendszerbe feltöltve az `.ipa`-t bárkinek küldhetsz meghívó linket, amire rányomva azonnal települ az iPhone-ra és iPadre!
