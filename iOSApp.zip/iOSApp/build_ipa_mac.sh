#!/usr/bin/env bash
set -e

cd "$(dirname "$0")"

if ! command -v xcodegen &> /dev/null; then
  echo "XcodeGen telepítése Homebrew-val..."
  brew install xcodegen
fi

echo "1. Xcode projekt generálása..."
xcodegen generate

echo "2. Fordítás Release módban (iPhone + iPad)..."
xcodebuild clean build \
  -project TothWorksAirRideSensor.xcodeproj \
  -scheme TothWorksAirRideSensor \
  -configuration Release \
  -sdk iphoneos \
  -derivedDataPath build \
  CODE_SIGNING_ALLOWED=NO \
  CODE_SIGNING_REQUIRED=NO \
  CODE_SIGN_IDENTITY=""

echo "3. IPA csomag készítése..."
rm -rf Payload "TothWorks Air Ride Sensor.ipa"
mkdir -p Payload
cp -r "build/Build/Products/Release-iphoneos/TothWorks Air Ride Sensor.app" Payload/
zip -r -9 "TothWorks Air Ride Sensor.ipa" Payload
rm -rf Payload

echo "KÉSZ! A telepítőfájl: $(pwd)/TothWorks Air Ride Sensor.ipa"
